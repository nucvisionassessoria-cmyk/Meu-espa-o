export type SeoCluster = {
  eyebrow: string;
  title: string;
  description: string;
  href: string;
  linkLabel: string;
  terms: string[];
};

export const seoClusters: SeoCluster[] = [
  {
    eyebrow: "Base e direção",
    title: "Consultoria e estruturação empresarial",
    description:
      "Para empresas que precisam organizar a operação antes de acelerar o crescimento.",
    href: "#o-que-fazemos",
    linkLabel: "Ver as frentes estruturadas",
    terms: [
      "consultoria empresarial",
      "assessoria empresarial",
      "estruturação empresarial",
      "consultoria de gestão empresarial",
      "consultoria para pequenas e médias empresas",
      "empresa de consultoria empresarial",
      "consultoria estratégica para empresas",
      "organização empresarial",
      "planejamento empresarial",
      "gestão integrada de negócios",
      "reestruturação de empresa",
      "consultoria para crescimento empresarial",
    ],
  },
  {
    eyebrow: "Operação replicável",
    title: "Processos, padrões e playbooks",
    description:
      "O trabalho deixa de depender da memória e passa a seguir uma lógica clara, treinável e acompanhável.",
    href: "#como-atuamos",
    linkLabel: "Entender a implementação",
    terms: [
      "mapeamento de processos",
      "padronização de processos",
      "organização de processos internos",
      "implantação de processos empresariais",
      "consultoria em processos",
      "manual de processos da empresa",
      "criação de playbooks empresariais",
      "playbook operacional",
      "documentação de processos",
      "fluxos de trabalho empresariais",
      "redução de retrabalho",
      "melhoria de processos",
    ],
  },
  {
    eyebrow: "Receita com método",
    title: "Estrutura comercial e vendas",
    description:
      "Da oportunidade ao fechamento, com processo, ferramenta, acompanhamento e desenvolvimento da equipe.",
    href: "#o-que-fazemos",
    linkLabel: "Conhecer a estrutura comercial",
    terms: [
      "consultoria comercial",
      "estruturação comercial",
      "processo de vendas",
      "organização do setor comercial",
      "implantação de CRM",
      "gestão de CRM",
      "funil de vendas",
      "script de vendas",
      "processo de follow-up",
      "qualificação de leads",
      "treinamento de vendas",
      "gestão de indicadores comerciais",
    ],
  },
  {
    eyebrow: "Demanda conectada",
    title: "Marketing e aquisição de clientes",
    description:
      "Muitas empresas chegam procurando uma agência de marketing. A NUC vai além: conecta aquisição à capacidade real de vender e entregar.",
    href: "#o-que-fazemos",
    linkLabel: "Ver marketing e aquisição",
    terms: [
      "agência de marketing para empresas",
      "assessoria de marketing",
      "consultoria de marketing",
      "marketing estratégico",
      "marketing focado em vendas",
      "planejamento de marketing",
      "marketing digital para empresas",
      "gestão de tráfego pago",
      "aquisição de clientes",
      "canais de aquisição",
      "posicionamento de marca",
      "integração entre marketing e vendas",
    ],
  },
  {
    eyebrow: "Clareza e velocidade",
    title: "Automação, ferramentas e indicadores",
    description:
      "Tecnologia aplicada ao fluxo certo, para reduzir tarefas manuais e dar visibilidade ao que acontece na empresa.",
    href: "#como-atuamos",
    linkLabel: "Ver a operação conectada",
    terms: [
      "automação de processos empresariais",
      "automação comercial",
      "ferramentas de gestão empresarial",
      "implantação de automações",
      "integração de ferramentas",
      "dashboard empresarial",
      "relatórios gerenciais",
      "indicadores de desempenho",
      "gestão por dados",
      "controle de operação",
      "organização de informações",
      "transparência na gestão",
    ],
  },
  {
    eyebrow: "Empresa menos dependente",
    title: "Gestão, liderança e cultura",
    description:
      "Responsabilidades, rituais e padrões que permitem à equipe avançar sem concentrar cada decisão no dono.",
    href: "#sobre",
    linkLabel: "Conhecer quem conduz",
    terms: [
      "cultura organizacional",
      "estrutura organizacional",
      "definição de cargos e responsabilidades",
      "gestão de equipe",
      "treinamento de liderança",
      "desenvolvimento de líderes",
      "rituais de gestão",
      "rotina de gestão",
      "delegação de tarefas",
      "alta performance empresarial",
      "alinhamento de equipe",
      "reduzir dependência do dono",
    ],
  },
  {
    eyebrow: "Sintomas pesquisados",
    title: "Quando o crescimento perde força",
    description:
      "Problemas que parecem separados, mas normalmente apontam para uma estrutura que não acompanhou o tamanho da empresa.",
    href: "#diagnostico",
    linkLabel: "Solicitar uma leitura do cenário",
    terms: [
      "empresa desorganizada",
      "empresa cresceu sem estrutura",
      "vendas sem processo",
      "equipe sem padrão",
      "processos na cabeça dos funcionários",
      "dono sobrecarregado",
      "falta de clareza na gestão",
      "retrabalho na empresa",
      "CRM desorganizado",
      "marketing não gera vendas",
      "leads sem acompanhamento",
      "empresa depende do dono para tudo",
    ],
  },
  {
    eyebrow: "Intenção de solução",
    title: "O que empresários querem resolver",
    description:
      "Buscas práticas de quem já percebeu o gargalo e procura um caminho para organizar, implementar e acompanhar.",
    href: "#diagnostico",
    linkLabel: "Começar pelo diagnóstico",
    terms: [
      "como organizar minha empresa",
      "como estruturar uma empresa",
      "como criar processos na empresa",
      "como padronizar o atendimento",
      "como organizar o setor comercial",
      "como implementar CRM",
      "como montar um playbook de vendas",
      "como melhorar a gestão da empresa",
      "como alinhar marketing e vendas",
      "como reduzir gargalos operacionais",
      "consultoria empresarial no Brasil",
      "assessoria empresarial com atuação nacional",
    ],
  },
];

export const seoTerms = seoClusters.flatMap((cluster) => cluster.terms);
