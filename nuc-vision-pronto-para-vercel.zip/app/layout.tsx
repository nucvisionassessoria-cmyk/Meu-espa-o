import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL ||
  "https://nuc-vision.nucvisionassessoria.chatgpt.site";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
  preload: false,
});

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  applicationName: "NUC Vision",
  title: {
    default: "Consultoria Empresarial, Processos e Vendas | NUC Vision",
    template: "%s | NUC Vision",
  },
  description:
    "Consultoria empresarial para organizar gestão, processos, vendas, marketing, automações e playbooks. Diagnóstico e implementação com atuação nacional.",
  alternates: {
    canonical: "/",
  },
  category: "Consultoria empresarial",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  openGraph: {
    title: "Consultoria Empresarial, Processos e Vendas | NUC Vision",
    description:
      "Gestão, processos, vendas, marketing, automações e playbooks conectados para transformar crescimento desorganizado em uma operação capaz de avançar.",
    type: "website",
    locale: "pt_BR",
    url: "/",
    siteName: "NUC Vision",
    images: [
      {
        url: "/nuc-ecosystem-final-2048.webp",
        width: 2048,
        height: 968,
        alt: "Ecossistema de implementação e acompanhamento da NUC Vision",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Consultoria Empresarial, Processos e Vendas | NUC Vision",
    description:
      "Estrutura, processos, vendas e marketing conectados a uma implementação real.",
    images: ["/nuc-ecosystem-final-2048.webp"],
  },
  icons: {
    icon: "/favicon.png",
    shortcut: "/favicon.png",
  },
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  colorScheme: "dark",
  themeColor: "#02050a",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
