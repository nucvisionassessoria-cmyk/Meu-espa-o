"use client";

import {
  ArrowDown,
  ArrowRight,
  AtSign,
  Check,
  ChevronDown,
  Mail,
  Menu,
  Pause,
  Play,
  UsersRound,
  X,
} from "lucide-react";
import dynamic from "next/dynamic";
import Image from "next/image";
import { FormEvent, useEffect, useRef, useState } from "react";

const EnergyGuide = dynamic(() => import("./EnergyGuide"), {
  ssr: false,
});

const NucleusScene = dynamic(() => import("./NucleusScene"), {
  ssr: false,
  loading: () => (
    <div
      className="nucleus-scene atomic-nucleus-scene atomic-scene-loading"
      aria-hidden="true"
    >
      <div className="atomic-css-fallback">
        <i />
        <i />
        <i />
      </div>
    </div>
  ),
});

type MotionMode = "full" | "reduced";

type PerformanceProfile = "standard" | "constrained";

const fallbackCauses = [
  "Gestão e responsabilidades",
  "Processos operacionais",
  "Estrutura comercial",
  "Marketing e aquisição",
];

function NucleusFallback() {
  return (
    <div
      className="nucleus-scene atomic-nucleus-scene atomic-scene-loading has-fallback"
      aria-hidden="true"
    >
      <div className="atomic-css-fallback">
        <i />
        <i />
        <i />
      </div>
      <div className="atomic-labels atomic-cause-labels">
        {fallbackCauses.map((cause) => (
          <span key={cause}>
            <i />
            {cause}
          </span>
        ))}
      </div>
    </div>
  );
}

const capabilities = [
  {
    name: "Gestão e responsabilidades",
    signal: "Quem decide. Quem executa. Quem responde.",
    copy:
      "Definimos papéis, liderança, rituais e indicadores para a empresa deixar de depender de versões, memória e centralização.",
    deliverables: [
      "Papéis e responsabilidades",
      "Rituais de gestão",
      "Indicadores de acompanhamento",
    ],
  },
  {
    name: "Processos operacionais",
    signal: "O trabalho deixa de morar na cabeça das pessoas.",
    copy:
      "Transformamos rotinas informais em fluxos claros, padrões replicáveis e passagens consistentes entre áreas.",
    deliverables: [
      "Mapas de processo",
      "Playbooks e padrões",
      "Rotinas documentadas",
    ],
  },
  {
    name: "Estrutura comercial",
    signal: "Da oportunidade à decisão, sem vazamentos invisíveis.",
    copy:
      "Organizamos abordagem, qualificação, CRM, follow-up, indicadores e treinamento para a venda funcionar como processo.",
    deliverables: [
      "CRM e etapas do funil",
      "Scripts e follow-up",
      "Treinamento comercial",
    ],
  },
  {
    name: "Marketing e aquisição",
    signal: "Demanda conectada à capacidade real de converter.",
    copy:
      "Alinhamos posicionamento, mensagem, aquisição e rastreio para o marketing deixar de operar separado da empresa.",
    deliverables: [
      "Posicionamento e mensagem",
      "Plano de aquisição",
      "Rastreio das oportunidades",
    ],
  },
];

const faqs = [
  {
    q: "Qual é a diferença entre a NUC e uma agência de marketing?",
    a:
      "Marketing é uma das frentes do núcleo. A NUC conecta gestão, processos, estrutura comercial e aquisição para que a demanda encontre uma empresa capaz de vender, entregar e evoluir.",
  },
  {
    q: "Como a estratégia chega à operação?",
    a:
      "Na Gestão de Jornada, a NUC estrutura processos, configura ferramentas, orienta responsáveis, treina a equipe e acompanha a adoção. O trabalho continua na rotina, nos indicadores e nas correções de rota.",
  },
  {
    q: "Como funciona o diagnóstico?",
    a:
      "Ele examina o contexto atual, cruza sintomas com evidências, identifica os gargalos de maior impacto e define a ordem adequada de ação antes de qualquer proposta.",
  },
  {
    q: "A NUC garante aumento de faturamento?",
    a:
      "Não fabricamos promessas que dependem de mercado, investimento e execução do cliente. Nosso compromisso está na qualidade da análise, direção, implementação, treinamento e acompanhamento.",
  },
];

function Brand() {
  return (
    <a className="brand" href="#inicio" aria-label="NUC Vision — início">
      <Image
        src="/nuc-mark.png"
        alt=""
        width={38}
        height={40}
        priority
        unoptimized
      />
      <span>
        NUC
        <b>VISION</b>
      </span>
    </a>
  );
}

function ActionLink({
  href,
  children,
  variant = "primary",
}: {
  href: string;
  children: React.ReactNode;
  variant?: "primary" | "ghost" | "light";
}) {
  return (
    <a
      className={`action-link action-link-${variant}`}
      href={href}
      data-magnetic
    >
      <span>{children}</span>
      <ArrowRight aria-hidden="true" size={18} strokeWidth={1.6} />
    </a>
  );
}

export default function InteractiveSite() {
  const rootRef = useRef<HTMLDivElement>(null);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const formStartedAtRef = useRef(0);
  const formSubmittingRef = useRef(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeCapability, setActiveCapability] = useState(0);
  const [motionMode, setMotionMode] = useState<MotionMode>("full");
  const [motionReady, setMotionReady] = useState(false);
  const [performanceProfile, setPerformanceProfile] =
    useState<PerformanceProfile>("constrained");
  const [enhancementsReady, setEnhancementsReady] = useState(false);
  const [formState, setFormState] = useState<
    "idle" | "sending" | "success" | "error"
  >("idle");
  const [formError, setFormError] = useState("");

  useEffect(() => {
    let idleHandle = 0;
    let fallbackTimer = 0;
    const frame = window.requestAnimationFrame(() => {
      formStartedAtRef.current = Date.now();
      let saved: string | null = null;
      try {
        saved = window.localStorage.getItem("nuc-motion-mode");
      } catch {
        // A preferência é opcional; o site continua funcional sem storage.
      }
      const systemReduced = window.matchMedia(
        "(prefers-reduced-motion: reduce)",
      ).matches;
      const connection = (
        navigator as Navigator & {
          connection?: { saveData?: boolean };
          deviceMemory?: number;
        }
      ).connection;
      const deviceMemory = (
        navigator as Navigator & { deviceMemory?: number }
      ).deviceMemory;
      const constrained =
        Boolean(connection?.saveData) ||
        window.matchMedia("(max-width: 820px)").matches ||
        (navigator.hardwareConcurrency || 8) <= 4 ||
        (deviceMemory || 8) <= 4;
      const profile: PerformanceProfile = constrained
        ? "constrained"
        : "standard";

      if (saved === "full" || saved === "reduced") {
        setMotionMode(saved);
      } else if (systemReduced) {
        setMotionMode("reduced");
      }
      setPerformanceProfile(profile);
      document.documentElement.dataset.performance = profile;
      setMotionReady(true);

      if (profile === "standard") {
        const loadEnhancements = () => setEnhancementsReady(true);
        const idleWindow = window as Window & {
          requestIdleCallback?: (
            callback: IdleRequestCallback,
            options?: IdleRequestOptions,
          ) => number;
        };

        if (idleWindow.requestIdleCallback) {
          idleHandle = idleWindow.requestIdleCallback(loadEnhancements, {
            timeout: 900,
          });
        } else {
          fallbackTimer = window.setTimeout(loadEnhancements, 180);
        }
      }
    });

    return () => {
      window.cancelAnimationFrame(frame);
      window.clearTimeout(fallbackTimer);
      if (idleHandle) {
        (
          window as Window & {
            cancelIdleCallback?: (handle: number) => void;
          }
        ).cancelIdleCallback?.(idleHandle);
      }
    };
  }, []);

  useEffect(() => {
    if (!motionReady) return;
    document.documentElement.dataset.motionMode = motionMode;
    try {
      window.localStorage.setItem("nuc-motion-mode", motionMode);
    } catch {
      // Preferência não essencial em navegadores com storage bloqueado.
    }
    window.dispatchEvent(
      new CustomEvent<MotionMode>("nuc-motion-change", {
        detail: motionMode,
      }),
    );
  }, [motionMode, motionReady]);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;

    const finePointer = window.matchMedia("(pointer: fine)");
    if (!finePointer.matches) return;
    let targetX = 0.5;
    let targetY = 0.5;
    let currentX = 0.5;
    let currentY = 0.5;
    let pointerFrame = 0;
    let reactionTimer = 0;

    const writePointer = () => {
      pointerFrame = 0;
      currentX += (targetX - currentX) * 0.11;
      currentY += (targetY - currentY) * 0.11;
      root.style.setProperty("--pointer-x", `${currentX}`);
      root.style.setProperty("--pointer-y", `${currentY}`);

      if (
        Math.abs(targetX - currentX) > 0.0005 ||
        Math.abs(targetY - currentY) > 0.0005
      ) {
        pointerFrame = window.requestAnimationFrame(writePointer);
      }
    };

    const requestPointerFrame = () => {
      if (!pointerFrame) {
        pointerFrame = window.requestAnimationFrame(writePointer);
      }
    };

    const pointerMove = (event: PointerEvent) => {
      if (!finePointer.matches || event.pointerType === "touch") return;
      targetX = event.clientX / Math.max(window.innerWidth, 1);
      targetY = event.clientY / Math.max(window.innerHeight, 1);
      root.dataset.pointerActive = "true";
      requestPointerFrame();
    };

    const pointerLeave = (event: PointerEvent) => {
      if (event.relatedTarget) return;
      targetX = 0.5;
      targetY = 0.5;
      delete root.dataset.pointerActive;
      requestPointerFrame();
    };

    const hero = root.querySelector<HTMLElement>(".hero");
    const pointerReaction = (event: PointerEvent) => {
      if (!hero) return;
      const bounds = hero.getBoundingClientRect();
      if (
        event.clientX < bounds.left ||
        event.clientX > bounds.right ||
        event.clientY < bounds.top ||
        event.clientY > bounds.bottom
      ) {
        return;
      }

      const x = ((event.clientX - bounds.left) / Math.max(bounds.width, 1)) * 100;
      const y = ((event.clientY - bounds.top) / Math.max(bounds.height, 1)) * 100;
      hero.style.setProperty("--reaction-x", `${x}%`);
      hero.style.setProperty("--reaction-y", `${y}%`);
      hero.classList.remove("is-reacting");
      void hero.offsetWidth;
      hero.classList.add("is-reacting");
      window.clearTimeout(reactionTimer);
      reactionTimer = window.setTimeout(
        () => hero.classList.remove("is-reacting"),
        760,
      );
    };

    const magneticElements = Array.from(
      root.querySelectorAll<HTMLElement>("[data-magnetic]"),
    );
    const surfaceElements = Array.from(
      root.querySelectorAll<HTMLElement>("[data-cursor-surface]"),
    );
    const interactiveElements = [...magneticElements, ...surfaceElements];
    const elementCleanups = interactiveElements.map((element) => {
      const onMove = (event: PointerEvent) => {
        if (!finePointer.matches || event.pointerType === "touch") return;
        const bounds = element.getBoundingClientRect();
        const x = Math.min(
          1,
          Math.max(0, (event.clientX - bounds.left) / Math.max(bounds.width, 1)),
        );
        const y = Math.min(
          1,
          Math.max(0, (event.clientY - bounds.top) / Math.max(bounds.height, 1)),
        );
        element.style.setProperty("--local-x", `${x}`);
        element.style.setProperty("--local-y", `${y}`);
        element.style.setProperty("--magnet-x", `${(x - 0.5) * 2}`);
        element.style.setProperty("--magnet-y", `${(y - 0.5) * 2}`);
        element.dataset.pointerOver = "true";
      };
      const onLeave = () => {
        element.style.setProperty("--local-x", "0.5");
        element.style.setProperty("--local-y", "0.5");
        element.style.setProperty("--magnet-x", "0");
        element.style.setProperty("--magnet-y", "0");
        delete element.dataset.pointerOver;
      };
      element.addEventListener("pointermove", onMove, { passive: true });
      element.addEventListener("pointerleave", onLeave, { passive: true });
      return () => {
        element.removeEventListener("pointermove", onMove);
        element.removeEventListener("pointerleave", onLeave);
      };
    });

    window.addEventListener("pointermove", pointerMove, { passive: true });
    window.addEventListener("pointerout", pointerLeave, { passive: true });
    window.addEventListener("pointerdown", pointerReaction, { passive: true });

    return () => {
      if (pointerFrame) window.cancelAnimationFrame(pointerFrame);
      window.clearTimeout(reactionTimer);
      window.removeEventListener("pointermove", pointerMove);
      window.removeEventListener("pointerout", pointerLeave);
      window.removeEventListener("pointerdown", pointerReaction);
      elementCleanups.forEach((cleanupElement) => cleanupElement());
    };
  }, []);

  useEffect(() => {
    if (
      !motionReady ||
      motionMode === "reduced" ||
      performanceProfile === "constrained" ||
      !enhancementsReady
    ) {
      return;
    }
    const root = rootRef.current;
    if (!root) return;

    let cleanup = () => {};

    const setup = async () => {
      const [{ default: gsap }, { ScrollTrigger }] = await Promise.all([
        import("gsap"),
        import("gsap/ScrollTrigger"),
      ]);

      gsap.registerPlugin(ScrollTrigger);
      const allowParallax = window.matchMedia(
        "(min-width: 821px) and (pointer: fine)",
      ).matches;

      const context = gsap.context(() => {
        if (allowParallax) {
          gsap.to(".hero-stars", {
            yPercent: 11,
            ease: "none",
            scrollTrigger: {
              trigger: ".hero",
              start: "top top",
              end: "bottom top",
              scrub: 1,
            },
          });

          gsap.to(".hero-depth-field", {
            yPercent: -5,
            scale: 1.035,
            ease: "none",
            scrollTrigger: {
              trigger: ".hero",
              start: "top top",
              end: "bottom top",
              scrub: 1,
            },
          });
        }

        gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach((element) => {
          gsap.fromTo(
            element,
            { autoAlpha: 0, y: 38 },
            {
              autoAlpha: 1,
              y: 0,
              duration: 0.8,
              ease: "power3.out",
              scrollTrigger: {
                trigger: element,
                start: "top 88%",
                toggleActions: "play none none reverse",
              },
            },
          );
        });

        if (allowParallax) {
          gsap.to(".growth-image", {
            yPercent: 7,
            scale: 1.04,
            ease: "none",
            scrollTrigger: {
              trigger: ".growth-section",
              start: "top bottom",
              end: "bottom top",
              scrub: 0.85,
            },
          });
        }

        gsap.fromTo(
          ".growth-cost",
          { autoAlpha: 0, y: 24 },
          {
            autoAlpha: 1,
            y: 0,
            duration: 0.65,
            stagger: 0.1,
            ease: "power3.out",
            scrollTrigger: {
              trigger: ".growth-costs",
              start: "top 84%",
              toggleActions: "play none none reverse",
            },
          },
        );

        if (allowParallax) {
          gsap.to(".architecture-horizon", {
            xPercent: 4,
            scale: 1.04,
            ease: "none",
            scrollTrigger: {
              trigger: ".architecture-section",
              start: "top bottom",
              end: "bottom top",
              scrub: 0.8,
            },
          });

          gsap.to(".operations-caustic", {
            yPercent: -13,
            rotate: 4,
            ease: "none",
            scrollTrigger: {
              trigger: ".operations-section",
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
            },
          });

          gsap.to(".diagnostic-light-field", {
            yPercent: 10,
            rotate: -5,
            ease: "none",
            scrollTrigger: {
              trigger: ".diagnostic-section",
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
            },
          });

          gsap.to(".authority-depth", {
            yPercent: -10,
            rotate: -3,
            ease: "none",
            scrollTrigger: {
              trigger: ".authority-section",
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
            },
          });

          gsap.to(".contact-atmosphere > div", {
            yPercent: -8,
            ease: "none",
            scrollTrigger: {
              trigger: ".contact-section",
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
            },
          });
        }

        ScrollTrigger.refresh();
      }, root);

      cleanup = () => context.revert();
    };

    setup();
    return () => cleanup();
  }, [enhancementsReady, motionMode, motionReady, performanceProfile]);

  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        const focusWasInMenu = mobileMenuRef.current?.contains(
          document.activeElement,
        );
        setMenuOpen(false);
        if (focusWasInMenu) {
          window.requestAnimationFrame(() => {
            menuButtonRef.current?.focus({ preventScroll: true });
          });
        }
      }
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, []);

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    let focusFrame = 0;
    if (menuOpen) {
      document.body.style.overflow = "hidden";
      focusFrame = window.requestAnimationFrame(() => {
        mobileMenuRef.current?.querySelector<HTMLElement>("a")?.focus({
          preventScroll: true,
        });
      });
    }
    return () => {
      if (focusFrame) window.cancelAnimationFrame(focusFrame);
      document.body.style.overflow = previousOverflow;
    };
  }, [menuOpen]);

  const changeMotion = () => {
    setMotionMode((current) =>
      current === "full" ? "reduced" : "full",
    );
  };

  const closeMenu = () => setMenuOpen(false);

  const submitLead = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;

    if (!form.reportValidity() || formSubmittingRef.current) return;

    formSubmittingRef.current = true;
    setFormState("sending");
    setFormError("");
    const data = new FormData(form);

    try {
      const response = await fetch("/api/lead", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: data.get("name"),
          whatsapp: data.get("whatsapp"),
          email: data.get("email"),
          socialProfile: data.get("socialProfile"),
          role: data.get("role"),
          teamSize: data.get("teamSize"),
          monthlyRevenue: data.get("monthlyRevenue"),
          website: data.get("website"),
          startedAt: formStartedAtRef.current,
        }),
      });

      const payload = (await response.json()) as {
        ok?: boolean;
        message?: string;
      };

      if (!response.ok || !payload.ok) {
        throw new Error(
          payload.message ||
            "Não foi possível enviar agora. Tente novamente.",
        );
      }

      form.reset();
      setFormState("success");
    } catch (error) {
      setFormError(
        error instanceof Error
          ? error.message
          : "Não foi possível enviar agora. Tente novamente.",
      );
      setFormState("error");
    } finally {
      formSubmittingRef.current = false;
    }
  };

  return (
    <div
      className="site-shell"
      ref={rootRef}
      data-active-capability={activeCapability}
    >
      <a className="skip-link" href="#conteudo">
        Ir para o conteúdo
      </a>

      {motionReady &&
      enhancementsReady &&
      performanceProfile === "standard" &&
      motionMode === "full" ? (
        <EnergyGuide motionMode={motionMode} />
      ) : null}

      <header className="site-header">
        <div className="nav-capsule">
          <Brand />
          <nav className="desktop-nav" aria-label="Navegação principal">
            <a href="#o-que-fazemos">O que fazemos</a>
            <a href="#como-atuamos">Como atuamos</a>
            <a href="#sobre">Quem conduz</a>
          </nav>
          <div className="header-actions">
            <button
              className="motion-toggle"
              type="button"
              onClick={changeMotion}
              aria-label={
                motionMode === "full"
                  ? "Reduzir animações"
                  : "Ativar animações"
              }
            >
              {motionMode === "full" ? (
                <Pause aria-hidden="true" size={16} />
              ) : (
                <Play aria-hidden="true" size={16} />
              )}
            </button>
            <a className="header-cta" href="#diagnostico" data-magnetic>
              Diagnóstico
              <ArrowRight aria-hidden="true" size={15} />
            </a>
            <button
              className="menu-button"
              ref={menuButtonRef}
              type="button"
              aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              onClick={() => setMenuOpen((current) => !current)}
            >
              {menuOpen ? (
                <X aria-hidden="true" size={20} />
              ) : (
                <Menu aria-hidden="true" size={20} />
              )}
            </button>
          </div>
        </div>
      </header>

      <div
        id="mobile-menu"
        ref={mobileMenuRef}
        className={`mobile-menu ${menuOpen ? "is-open" : ""}`}
        aria-hidden={!menuOpen}
      >
        <nav aria-label="Navegação móvel">
          <a
            href="#o-que-fazemos"
            tabIndex={menuOpen ? 0 : -1}
            onClick={closeMenu}
          >
            O que fazemos
          </a>
          <a
            href="#como-atuamos"
            tabIndex={menuOpen ? 0 : -1}
            onClick={closeMenu}
          >
            Como atuamos
          </a>
          <a
            href="#sobre"
            tabIndex={menuOpen ? 0 : -1}
            onClick={closeMenu}
          >
            Quem conduz
          </a>
          <a
            href="#diagnostico"
            tabIndex={menuOpen ? 0 : -1}
            onClick={closeMenu}
          >
            Solicitar diagnóstico
          </a>
        </nav>
      </div>

      <main id="conteudo">
        <div className="opening-continuum">
          <section className="hero" id="inicio" aria-labelledby="hero-title">
          <div className="hero-stars" aria-hidden="true" />
          <div className="hero-depth-field" aria-hidden="true">
            <i />
            <i />
            <i />
          </div>
          {enhancementsReady && performanceProfile === "standard" ? (
            <NucleusScene />
          ) : (
            <NucleusFallback />
          )}
          <div className="hero-veil" aria-hidden="true" />
          <div className="hero-content">
            <p className="hero-kicker">
              Estruturação empresarial com visão de núcleo
            </p>
            <h1 className="hero-title" id="hero-title">
              <span className="hero-line hero-line-near">
                Quem olha a superfície
              </span>
              <span className="hero-line hero-line-mid">
                vê problemas separados.
              </span>
              <strong className="hero-line hero-line-core">
                Nós enxergamos o <em>núcleo.</em>
              </strong>
            </h1>
            <p className="hero-description">
              Para empresas que já vendem e têm equipe, mas cresceram mais
              rápido do que a própria operação. A NUC conecta gestão,
              processos, vendas e marketing para transformar improviso em
              estrutura.
            </p>
            <div className="hero-actions">
              <ActionLink href="#diagnostico">
                Solicitar diagnóstico estrutural
              </ActionLink>
              <a className="hero-text-link" href="#o-que-fazemos">
                Ver o que estruturamos
                <ArrowDown aria-hidden="true" size={17} />
              </a>
            </div>
          </div>
          </section>

          <section className="growth-section" aria-labelledby="growth-title">
          <Image
            className="growth-image"
            src="/human-operations-table.webp"
            alt=""
            fill
            loading="lazy"
            decoding="async"
            sizes="100vw"
            unoptimized
          />
          <div className="growth-shadow" aria-hidden="true" />
          <div className="growth-light" aria-hidden="true" />
          <div className="growth-content">
            <p className="section-kicker" data-reveal>
              Quando a empresa cresce
            </p>
            <h2 id="growth-title" data-reveal>
              O improviso deixa de ser agilidade.
              <span> E começa a cobrar.</span>
            </h2>
            <p className="growth-lead" data-reveal>
              A empresa vende, contrata e se movimenta — mas decisões,
              responsabilidades e rotinas continuam presas em acordos
              informais. É nessa distância que o crescimento começa a perder
              força.
            </p>
            <div className="growth-costs">
              <p className="growth-cost">Decisões travam no dono.</p>
              <p className="growth-cost">A equipe cria caminhos diferentes.</p>
              <p className="growth-cost">
                Oportunidades chegam a uma operação que ainda não sustenta o
                próximo nível.
              </p>
            </div>
          </div>
          </section>

          <section
            className="architecture-section"
            id="o-que-fazemos"
            aria-labelledby="architecture-title"
          >
          <div className="architecture-horizon" aria-hidden="true">
            <i />
            <i />
          </div>
          <div className="architecture-shell">
            <div className="architecture-intro">
              <p className="section-kicker" data-reveal>
                O que a NUC estrutura
              </p>
              <h2 id="architecture-title" data-reveal>
                Quatro frentes.
                <span> Uma empresa funcionando inteira.</span>
              </h2>
              <p data-reveal>
                Ligamos quem decide, como o trabalho acontece, como a empresa
                vende e como novas oportunidades chegam. Escolha uma frente
                para entender o que muda na prática.
              </p>
            </div>

            <div className="architecture-stage" data-reveal>
              <div
                className="architecture-nav"
                role="tablist"
                aria-label="Frentes estruturadas pela NUC"
              >
                {capabilities.map((capability, index) => (
                  <button
                    key={capability.name}
                    type="button"
                    role="tab"
                    id={`architecture-tab-${index}`}
                    aria-controls={`architecture-panel-${index}`}
                    aria-selected={activeCapability === index}
                    className={activeCapability === index ? "is-active" : ""}
                    onClick={() => setActiveCapability(index)}
                    onPointerEnter={() => setActiveCapability(index)}
                  >
                    <span>{capability.name}</span>
                    <ArrowRight aria-hidden="true" size={18} />
                  </button>
                ))}
              </div>

              <div className="architecture-panels">
                {capabilities.map((capability, index) => (
                  <article
                    key={capability.name}
                    id={`architecture-panel-${index}`}
                    role="tabpanel"
                    aria-labelledby={`architecture-tab-${index}`}
                    aria-hidden={activeCapability !== index}
                    className={
                      activeCapability === index
                        ? "architecture-panel is-active"
                        : "architecture-panel"
                    }
                  >
                    <p>{capability.signal}</p>
                    <h3>{capability.name}</h3>
                    <strong>{capability.copy}</strong>
                    <ul>
                      {capability.deliverables.map((deliverable) => (
                        <li key={deliverable}>
                          <Check aria-hidden="true" size={17} />
                          {deliverable}
                        </li>
                      ))}
                    </ul>
                  </article>
                ))}
              </div>
            </div>
          </div>
          </section>

          <div className="operations-diagnostic-continuum">
            <section
              className="operations-section"
              id="como-atuamos"
              aria-labelledby="operations-title"
            >
          <div className="operations-universe" aria-hidden="true">
            <i />
            <i />
            <i />
          </div>
          <div className="operations-caustic" aria-hidden="true" />
          <div className="operations-shade" aria-hidden="true" />
          <div className="operations-content">
            <p className="section-kicker" data-reveal>
              Implementação acompanhada
            </p>
            <h2 id="operations-title" data-reveal>
              A estratégia entra na operação.
              <span> E evolui com quem executa.</span>
            </h2>
            <p data-reveal>
              Na Gestão de Jornada, a NUC conecta prioridades, processos,
              ferramentas e pessoas. Estruturamos a execução, treinamos a
              equipe, acompanhamos indicadores e corrigimos a rota para que a
              mudança permaneça funcionando no dia a dia.
            </p>
            <div className="operations-flow" data-reveal>
              {[
                "Diagnosticar",
                "Priorizar",
                "Implementar",
                "Treinar",
                "Acompanhar",
              ].map((item) => (
                <span key={item}>{item}</span>
              ))}
            </div>
          </div>
          <figure
            className="operations-scene"
          >
            <picture className="ecosystem-desktop-art">
              <source
                srcSet="/nuc-ecosystem-final-1280.webp 1280w, /nuc-ecosystem-final-2048.webp 2048w"
                sizes="(max-width: 560px) calc(100vw - 8px), (max-width: 1100px) calc(100vw - 16px), (min-width: 1862px) 1600px, 86vw"
                type="image/webp"
              />
              {/* A composição usa art direction própria e não passa pelo proxy de imagens. */}
              <img
                src="/nuc-ecosystem-final-2048.webp"
                alt="Ecossistema NUC em operação: implementação de playbooks, CRM e organização comercial, cultura, relatórios, marketing, gestão de tráfego, canais de aquisição e treinamento conectados ao núcleo da empresa."
                width={2048}
                height={968}
                loading="lazy"
                decoding="async"
              />
            </picture>
          </figure>
          </section>

            <div className="clarity-blend" aria-hidden="true" />

            <section
              className="diagnostic-section"
              aria-labelledby="diagnostic-title"
            >
          <div className="diagnostic-light-field" aria-hidden="true" />
          <div className="diagnostic-intro">
            <p className="section-kicker dark" data-reveal>
              O primeiro passo
            </p>
            <h2 id="diagnostic-title" data-reveal>
              Você não recebe uma opinião.
              <span> Recebe uma ordem de ação.</span>
            </h2>
            <p data-reveal>
              O Diagnóstico Estrutural cruza sintomas com evidências e mostra
              onde a empresa perde força, o que precisa vir primeiro e qual
              caminho faz sentido.
            </p>
          </div>

          <div className="diagnostic-outcomes">
            {[
              {
                title: "Cenário real",
                copy: "Uma leitura objetiva das frentes que sustentam a operação.",
              },
              {
                title: "Gargalos prioritários",
                copy: "Os pontos de perda que mais comprometem o crescimento.",
              },
              {
                title: "Ordem de ação",
                copy: "O que vem primeiro, o que pode esperar e quem precisa assumir.",
              },
              {
                title: "Próximo caminho",
                copy: "Planejar internamente ou implementar junto com a NUC.",
              },
            ].map((item) => (
              <article data-reveal key={item.title}>
                <h3>{item.title}</h3>
                <p>{item.copy}</p>
              </article>
            ))}
          </div>
          <div
            className="section-transition transition-from-clarity"
            aria-hidden="true"
          >
            <i />
            <i />
          </div>
            </section>
          </div>
        </div>

        <div className="closing-continuum">
          <section
            className="authority-section"
            id="sobre"
            aria-labelledby="authority-title"
          >
          <div className="authority-depth" aria-hidden="true" />
          <div className="authority-heading">
            <p className="section-kicker" data-reveal>
              Quem conduz a NUC
            </p>
            <h2 id="authority-title" data-reveal>
              Estratégia e implementação
              <span> trabalhando sobre o mesmo diagnóstico.</span>
            </h2>
          </div>

          <div className="authority-people">
            <article
              className="authority-person authority-person-iago"
              data-reveal
              data-cursor-surface
            >
              <div className="authority-portrait">
                <Image
                  className="authority-person-image"
                  src="/team/iago-aprigio.webp"
                  alt="Retrato de Iago Aprígio, da NUC Vision"
                  fill
                  sizes="(max-width: 760px) 31vw, (max-width: 1100px) 15vw, 205px"
                  unoptimized
                />
                <span className="authority-person-number" aria-hidden="true">
                  01
                </span>
              </div>
              <div className="authority-person-copy">
                <div className="authority-nameplate">
                  <p>Estratégia · Posicionamento · Aquisição</p>
                  <h3>Iago Aprígio</h3>
                </div>
                <span>Direção estratégica</span>
                <strong>
                  Conecta posicionamento, mensagem, aquisição e condução
                  comercial — da atenção à oportunidade e à decisão.
                </strong>
              </div>
            </article>
            <article
              className="authority-person authority-person-derick"
              data-reveal
              data-cursor-surface
            >
              <div className="authority-portrait">
                <Image
                  className="authority-person-image"
                  src="/team/derick-araujo.webp"
                  alt="Retrato de Derick Araújo, da NUC Vision"
                  fill
                  sizes="(max-width: 760px) 31vw, (max-width: 1100px) 15vw, 205px"
                  unoptimized
                />
                <span className="authority-person-number" aria-hidden="true">
                  02
                </span>
              </div>
              <div className="authority-person-copy">
                <div className="authority-nameplate">
                  <p>Estrutura · Processos · Implementação</p>
                  <h3>Derick Araújo</h3>
                </div>
                <span>Direção de implementação</span>
                <strong>
                  Transforma direção em fluxo, ferramenta, treinamento e rotina
                  executável junto à equipe.
                </strong>
              </div>
            </article>
          </div>
          </section>

          <section className="faq-section" aria-labelledby="faq-title">
          <div className="faq-heading">
            <p className="section-kicker" data-reveal>
              Sem letra miúda
            </p>
            <h2 id="faq-title" data-reveal>
              Clareza também está
              <span> no que não prometemos.</span>
            </h2>
          </div>
          <div className="faq-list">
            {faqs.map((faq) => (
              <details data-reveal key={faq.q}>
                <summary>
                  <strong>{faq.q}</strong>
                  <ChevronDown aria-hidden="true" size={22} />
                </summary>
                <p>{faq.a}</p>
              </details>
            ))}
          </div>
          </section>

          <div className="conversion-continuum">
            <section
              className="routes-bridge"
              aria-label="Caminhos possíveis após o diagnóstico"
            >
              <div className="routes">
              <a
                className="route route-planning"
                href="#diagnostico"
                data-cursor-surface
              >
                <p>Direção para execução interna</p>
                <h3>
                  Planejamento
                  <span> Completo</span>
                </h3>
                <strong>
                  Cenário, prioridades, responsáveis, sequência de ações e
                  critérios para a empresa conduzir a mudança.
                </strong>
                <span className="route-action">
                  Entender este caminho
                  <ArrowRight aria-hidden="true" size={20} />
                </span>
              </a>

              <a
                className="route route-management"
                href="#diagnostico"
                data-cursor-surface
              >
                <p>NUC presente na implementação</p>
                <h3>
                  Gestão de
                  <span> Jornada</span>
                </h3>
                <strong>
                  Processos, ferramentas, playbooks, treinamento e
                  acompanhamento para a direção entrar na rotina.
                </strong>
                <span className="route-action">
                  Entender este caminho
                  <ArrowRight aria-hidden="true" size={20} />
                </span>
              </a>
              </div>
            </section>

            <section
              className="contact-section"
              id="diagnostico"
              aria-labelledby="contact-title"
            >
          <div className="contact-atmosphere" aria-hidden="true">
            <div />
          </div>
          <div className="contact-copy">
            <p className="section-kicker" data-reveal>
              O primeiro passo é enxergar
            </p>
            <h2 id="contact-title" data-reveal>
              Descubra o que acontece
              <span> no núcleo da sua empresa.</span>
            </h2>
            <p data-reveal>
              Solicite o Diagnóstico Estrutural da NUC Vision. Antes de
              recomendar qualquer solução, vamos entender o contexto, os
              gargalos e a ordem correta da mudança.
            </p>
            <span className="contact-proof" data-reveal>
              Atuação nacional · Análise conduzida com um responsável pela
              decisão
            </span>
          </div>

          <div className="form-shell" data-reveal>
            {formState === "success" ? (
              <div className="form-success" role="status">
                <span>
                  <Check aria-hidden="true" size={28} />
                </span>
                <p>Recebemos suas informações.</p>
                <h3>
                  Agora vamos entender o contexto antes de propor o próximo
                  passo.
                </h3>
                <strong>
                  Um responsável da NUC entrará em contato pelo telefone
                  informado.
                </strong>
                <button
                  type="button"
                  onClick={() => {
                    formStartedAtRef.current = Date.now();
                    setFormState("idle");
                  }}
                >
                  Enviar outra resposta
                </button>
              </div>
            ) : (
              <form onSubmit={submitLead} noValidate>
                <label className="form-trap" aria-hidden="true">
                  <span>Não preencha este campo</span>
                  <input
                    name="website"
                    type="text"
                    autoComplete="off"
                    tabIndex={-1}
                  />
                </label>
                <div className="field-row">
                  <label>
                    <span>Nome *</span>
                    <input
                      name="name"
                      type="text"
                      autoComplete="name"
                      required
                      maxLength={100}
                      placeholder="Seu nome completo"
                    />
                  </label>
                  <label>
                    <span>Telefone com DDD *</span>
                    <input
                      name="whatsapp"
                      type="tel"
                      autoComplete="tel"
                      inputMode="tel"
                      required
                      maxLength={20}
                      pattern="[0-9\s()+-]{10,20}"
                      placeholder="(00) 00000-0000"
                    />
                  </label>
                </div>
                <div className="field-row">
                  <label>
                    <span>E-mail *</span>
                    <input
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      maxLength={160}
                      placeholder="seu@email.com"
                    />
                  </label>
                  <label>
                    <span>Site ou Instagram da empresa</span>
                    <input
                      name="socialProfile"
                      type="text"
                      autoComplete="url"
                      maxLength={240}
                      placeholder="@suaempresa ou www.suaempresa.com.br"
                    />
                  </label>
                </div>
                <div className="field-row">
                  <label>
                    <span>Qual é seu cargo? *</span>
                    <select name="role" required defaultValue="">
                      <option value="" disabled>
                        Selecione seu cargo
                      </option>
                      <option>Proprietário(a) / Sócio(a)</option>
                      <option>Diretor(a)</option>
                      <option>Gerente</option>
                      <option>Coordenador(a) / Líder</option>
                      <option>Analista / Especialista</option>
                      <option>Outro cargo</option>
                    </select>
                  </label>
                  <label>
                    <span>Número total de colaboradores *</span>
                    <select name="teamSize" required defaultValue="">
                      <option value="" disabled>
                        Selecione a quantidade
                      </option>
                      <option>1 a 5 colaboradores</option>
                      <option>6 a 10 colaboradores</option>
                      <option>11 a 30 colaboradores</option>
                      <option>31 a 50 colaboradores</option>
                      <option>51 a 100 colaboradores</option>
                      <option>Mais de 100 colaboradores</option>
                    </select>
                  </label>
                </div>
                <div className="field-row field-row-single">
                  <label>
                    <span>Faturamento médio mensal *</span>
                    <select name="monthlyRevenue" required defaultValue="">
                      <option value="" disabled>
                        Selecione a faixa
                      </option>
                      <option>Até R$ 50 mil</option>
                      <option>De R$ 50 mil a R$ 100 mil</option>
                      <option>De R$ 100 mil a R$ 300 mil</option>
                      <option>De R$ 300 mil a R$ 500 mil</option>
                      <option>De R$ 500 mil a R$ 1 milhão</option>
                      <option>Acima de R$ 1 milhão</option>
                      <option>Prefiro conversar sobre isso</option>
                    </select>
                  </label>
                </div>
                {formState === "error" && (
                  <p className="form-error" role="alert">
                    {formError}
                  </p>
                )}
                <button
                  className="submit-button"
                  type="submit"
                  disabled={formState === "sending"}
                >
                  <span>
                    {formState === "sending"
                      ? "Enviando..."
                      : "Quero meu Diagnóstico"}
                  </span>
                  <ArrowRight aria-hidden="true" size={19} />
                </button>
              </form>
            )}
          </div>
            </section>
          </div>
        </div>
      </main>

      <footer className="site-footer">
        <div className="footer-branding">
          <Brand />
          <p>
            Estrutura, processos, vendas e marketing funcionando como um núcleo.
          </p>
        </div>

        <nav
          className="footer-contacts"
          aria-label="Canais comerciais da NUC Vision"
        >
          <a
            href="https://www.instagram.com/nucvision?igsh=MWczOGd3Zm5tNHluMA%3D%3D&utm_source=qr"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram da NUC Vision — abre em uma nova aba"
          >
            <AtSign aria-hidden="true" size={18} strokeWidth={1.7} />
            <span>
              <small>Instagram</small>
              @nucvision
            </span>
          </a>
          <a
            href="https://www.facebook.com/profile.php?id=61575350444868"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook da NUC Vision — abre em uma nova aba"
          >
            <UsersRound aria-hidden="true" size={18} strokeWidth={1.7} />
            <span>
              <small>Facebook</small>
              NUC Vision
            </span>
          </a>
          <a
            href="mailto:nucvisionassessoria@gmail.com"
            aria-label="Enviar e-mail comercial para a NUC Vision"
          >
            <Mail aria-hidden="true" size={18} strokeWidth={1.7} />
            <span>
              <small>E-mail comercial</small>
              nucvisionassessoria@gmail.com
            </span>
          </a>
        </nav>

        <span className="footer-copyright">
          © {new Date().getFullYear()} NUC Vision
        </span>
      </footer>
    </div>
  );
}
