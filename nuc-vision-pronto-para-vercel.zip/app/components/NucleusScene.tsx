"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";

const CAUSES = [
  "ESTRUTURA COMERCIAL",
  "PROCESSOS OPERACIONAIS",
  "GESTÃO E RESPONSABILIDADES",
  "MARKETING E AQUISIÇÃO",
];

const SYMPTOMS = ["DEPENDÊNCIA", "RETRABALHO", "VAZAMENTO", "DESPERDÍCIO"];

type NucleusSceneProps = {
  compact?: boolean;
};

type Nucleon = {
  base: THREE.Vector3;
  fracture: THREE.Vector3;
  mesh: THREE.Mesh<THREE.BufferGeometry, THREE.MeshPhysicalMaterial>;
  outward: THREE.Vector3;
  shape: THREE.Vector3;
  spin: THREE.Vector3;
};

type Orbit = {
  electron: THREE.Mesh<THREE.SphereGeometry, THREE.MeshPhysicalMaterial>;
  group: THREE.Group;
  lineMaterial: THREE.LineBasicMaterial;
  phase: number;
  speed: number;
};

const clamp = (value: number, min = 0, max = 1) =>
  Math.min(max, Math.max(min, value));

const lerp = (from: number, to: number, amount: number) =>
  from + (to - from) * amount;

const smoothstep = (from: number, to: number, value: number) => {
  const amount = clamp((value - from) / Math.max(to - from, 0.0001));
  return amount * amount * (3 - 2 * amount);
};

const smootherstep = (from: number, to: number, value: number) => {
  const amount = clamp((value - from) / Math.max(to - from, 0.0001));
  return (
    amount *
    amount *
    amount *
    (amount * (amount * 6 - 15) + 10)
  );
};

const easeInOutCubic = (value: number) =>
  value < 0.5
    ? 4 * value * value * value
    : 1 - Math.pow(-2 * value + 2, 3) / 2;

const createSeededRandom = () => {
  let seed = 4121991;
  return () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
};

const vertexShader = `
  uniform float uTime;
  uniform float uFracture;
  uniform float uOpacity;
  varying vec3 vNormalView;
  varying vec3 vViewDirection;
  varying float vEnergy;

  float hash(vec3 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
  }

  float noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(mix(hash(i + vec3(0,0,0)), hash(i + vec3(1,0,0)), f.x),
          mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
      mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
          mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y),
      f.z
    );
  }

  void main() {
    float broad = noise(normal * 2.7 + uTime * 0.12);
    float detail = noise(normal * 7.2 - uTime * 0.19);
    float pulse = sin(uTime * 1.5 + position.y * 3.4) * 0.5 + 0.5;
    float displacement = (broad - 0.5) * 0.13 + (detail - 0.5) * 0.045;
    displacement += pulse * 0.025 + uFracture * detail * 0.055;

    vec3 transformed = position + normal * displacement;
    vec4 mvPosition = modelViewMatrix * vec4(transformed, 1.0);
    vNormalView = normalize(normalMatrix * normal);
    vViewDirection = normalize(-mvPosition.xyz);
    vEnergy = broad * 0.58 + detail * 0.28 + pulse * 0.14;
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = `
  uniform float uTime;
  uniform float uFracture;
  uniform float uOpacity;
  varying vec3 vNormalView;
  varying vec3 vViewDirection;
  varying float vEnergy;

  void main() {
    float facing = clamp(dot(normalize(vNormalView), normalize(vViewDirection)), 0.0, 1.0);
    float fresnel = pow(1.0 - facing, 2.2);
    float vein = smoothstep(0.67, 0.84, vEnergy + sin(uTime * 1.35) * 0.045);
    float hot = smoothstep(0.82, 0.98, vEnergy + uFracture * 0.12);

    vec3 abyss = vec3(0.004, 0.012, 0.032);
    vec3 mineral = vec3(0.018, 0.12, 0.34);
    vec3 oxidized = vec3(0.07, 0.37, 0.72);
    vec3 pearl = vec3(0.55, 0.78, 0.92);
    vec3 color = mix(abyss, mineral, 0.22 + vEnergy * 0.48);
    color = mix(color, oxidized, vein * 0.28 + uFracture * 0.18);
    color = mix(color, pearl, fresnel * 0.32 + hot * 0.22);

    gl_FragColor = vec4(color, 0.94 * uOpacity);
  }
`;

export default function NucleusScene({ compact = false }: NucleusSceneProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const labelRefs = useRef<Array<HTMLSpanElement | null>>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const root = rootRef.current;
    const canvas = canvasRef.current;
    if (!root || !canvas) return;

    const random = createSeededRandom();
    let renderer: THREE.WebGLRenderer;

    const probe = document.createElement("canvas");
    const contextOptions = {
      alpha: true,
      failIfMajorPerformanceCaveat: true,
      powerPreference: "high-performance" as WebGLPowerPreference,
    };
    const supportsWebGL = Boolean(
      probe.getContext("webgl2", contextOptions) ||
        probe.getContext("webgl", contextOptions),
    );

    if (!supportsWebGL) {
      root.classList.add("has-fallback");
      return () => root.classList.remove("has-fallback");
    }

    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        alpha: true,
        antialias: true,
        powerPreference: "high-performance",
        premultipliedAlpha: false,
      });
    } catch {
      root.classList.add("has-fallback");
      return () => root.classList.remove("has-fallback");
    }

    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.02;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(41, 1, 0.1, 100);
    camera.position.set(0, 0.08, 7.8);

    const composer = new EffectComposer(renderer);
    const renderPass = new RenderPass(scene, camera);
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(1, 1),
      compact ? 0.48 : 0.58,
      0.52,
      0.34,
    );
    composer.addPass(renderPass);
    composer.addPass(bloomPass);

    const atom = new THREE.Group();
    scene.add(atom);

    const coreUniforms = {
      uTime: { value: 0 },
      uFracture: { value: 0 },
      uOpacity: { value: 1 },
    };
    const coreGeometry = new THREE.IcosahedronGeometry(0.72, 5);
    const coreMaterial = new THREE.ShaderMaterial({
      uniforms: coreUniforms,
      vertexShader,
      fragmentShader,
      transparent: true,
      depthWrite: false,
    });
    const energyCore = new THREE.Mesh(coreGeometry, coreMaterial);
    atom.add(energyCore);

    const shellGeometry = new THREE.IcosahedronGeometry(1.32, 3);
    const shellMaterial = new THREE.MeshBasicMaterial({
      color: 0x55b8ff,
      transparent: true,
      opacity: 0.006,
      wireframe: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const energyShell = new THREE.Mesh(shellGeometry, shellMaterial);
    atom.add(energyShell);

    const nucleonGeometry = new THREE.IcosahedronGeometry(
      compact ? 0.3 : 0.33,
      3,
    );
    const nucleonPositions = nucleonGeometry.attributes.position;
    const nucleonVertex = new THREE.Vector3();
    for (let index = 0; index < nucleonPositions.count; index += 1) {
      nucleonVertex.fromBufferAttribute(nucleonPositions, index);
      const irregularity =
        1 +
        Math.sin(
          nucleonVertex.x * 17.3 +
            nucleonVertex.y * 11.7 +
            nucleonVertex.z * 23.1,
        ) *
          0.045 +
        Math.cos(
          nucleonVertex.x * 29.1 -
            nucleonVertex.y * 19.4 +
            nucleonVertex.z * 13.6,
        ) *
          0.018;
      nucleonVertex.multiplyScalar(irregularity);
      nucleonPositions.setXYZ(
        index,
        nucleonVertex.x,
        nucleonVertex.y,
        nucleonVertex.z,
      );
    }
    nucleonGeometry.computeVertexNormals();
    const nucleonMaterials = [
      new THREE.MeshPhysicalMaterial({
        color: 0x10192b,
        emissive: 0x092c68,
        emissiveIntensity: 0.08,
        metalness: 0.16,
        roughness: 0.62,
        clearcoat: 0.28,
        clearcoatRoughness: 0.52,
      }),
      new THREE.MeshPhysicalMaterial({
        color: 0x172b4b,
        emissive: 0x0b3e91,
        emissiveIntensity: 0.07,
        metalness: 0.08,
        roughness: 0.66,
        clearcoat: 0.22,
        clearcoatRoughness: 0.58,
      }),
      new THREE.MeshPhysicalMaterial({
        color: 0x52677e,
        emissive: 0x164d9d,
        emissiveIntensity: 0.05,
        metalness: 0.03,
        roughness: 0.57,
        clearcoat: 0.24,
        clearcoatRoughness: 0.47,
      }),
    ];

    const nucleons: Nucleon[] = [];
    const nucleonCount = compact ? 24 : 36;
    const goldenAngle = Math.PI * (3 - Math.sqrt(5));
    for (let index = 0; index < nucleonCount; index += 1) {
      const y = 1 - (index / Math.max(nucleonCount - 1, 1)) * 2;
      const radius = Math.sqrt(1 - y * y);
      const theta = goldenAngle * index;
      const layer = 1.04 + random() * 0.18;
      const base = new THREE.Vector3(
        Math.cos(theta) * radius,
        y,
        Math.sin(theta) * radius,
      ).multiplyScalar(layer);
      const cleavageDirections = [
        new THREE.Vector3(0.18, 0.1, 0.04),
        new THREE.Vector3(-0.16, 0.12, -0.03),
        new THREE.Vector3(0.12, -0.16, -0.05),
        new THREE.Vector3(-0.14, -0.12, 0.06),
      ];
      const fracture = base
        .clone()
        .normalize()
        .multiplyScalar(0.46 + random() * 0.3)
        .add(
          cleavageDirections[index % cleavageDirections.length]
            .clone()
            .multiplyScalar(1.35),
        );
      const mesh = new THREE.Mesh(
        nucleonGeometry,
        nucleonMaterials[index % nucleonMaterials.length],
      );
      const scale = 0.78 + random() * 0.34;
      const shape = new THREE.Vector3(
        0.88 + random() * 0.24,
        0.86 + random() * 0.28,
        0.9 + random() * 0.22,
      );
      mesh.scale.set(
        shape.x * scale,
        shape.y * scale,
        shape.z * scale,
      );
      mesh.position.copy(base);
      atom.add(mesh);
      nucleons.push({
        base,
        fracture,
        mesh,
        outward: base.clone().normalize(),
        shape,
        spin: new THREE.Vector3(
          (random() - 0.5) * 2,
          (random() - 0.5) * 2,
          (random() - 0.5) * 2,
        ),
      });
    }

    const orbitRoot = new THREE.Group();
    atom.add(orbitRoot);
    const electronGeometry = new THREE.SphereGeometry(
      compact ? 0.105 : 0.13,
      24,
      24,
    );
    const electronMaterials = CAUSES.map(
      (_, index) =>
        new THREE.MeshPhysicalMaterial({
          color: index % 2 ? 0x65b7ff : 0xe2f4ff,
          emissive: index % 2 ? 0x145bff : 0x2ba7ff,
          emissiveIntensity: 1.02,
          roughness: 0.26,
          metalness: 0.08,
          clearcoat: 0.62,
          transparent: true,
        }),
    );
    const orbitTilts = [
      new THREE.Euler(0.72, 0.12, -0.28),
      new THREE.Euler(-0.44, 0.58, 0.3),
      new THREE.Euler(0.18, -0.62, 0.68),
      new THREE.Euler(-0.76, -0.18, -0.48),
    ];
    const orbits: Orbit[] = [];

    for (let index = 0; index < CAUSES.length; index += 1) {
      const group = new THREE.Group();
      group.rotation.copy(orbitTilts[index]);
      const radiusX = 1.88 + index * 0.18;
      const radiusY = radiusX * (0.44 + index * 0.024);
      const points = Array.from({ length: 128 }, (_, pointIndex) => {
        const angle = (pointIndex / 127) * Math.PI * 2;
        return new THREE.Vector3(
          Math.cos(angle) * radiusX,
          Math.sin(angle) * radiusY,
          0,
        );
      });
      const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
      const lineMaterial = new THREE.LineBasicMaterial({
        color: index % 2 ? 0x2e79ff : 0x76ddff,
        transparent: true,
        opacity: compact ? 0.09 : 0.13,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const line = new THREE.LineLoop(lineGeometry, lineMaterial);
      group.add(line);

      const electron = new THREE.Mesh(
        electronGeometry,
        electronMaterials[index],
      );
      group.add(electron);
      orbitRoot.add(group);
      orbits.push({
        electron,
        group,
        lineMaterial,
        phase: index * (Math.PI / 2) + index * 0.31,
        speed: 0.17 + index * 0.022,
      });
    }

    const haloGeometry = new THREE.SphereGeometry(1.72, 40, 40);
    const haloMaterial = new THREE.MeshBasicMaterial({
      color: 0x2b83ff,
      transparent: true,
      opacity: 0.014,
      side: THREE.BackSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const halo = new THREE.Mesh(haloGeometry, haloMaterial);
    atom.add(halo);

    const ambientLight = new THREE.AmbientLight(0x182f68, 1.02);
    const keyLight = new THREE.PointLight(0xdaf3ff, 19, 18, 2);
    keyLight.position.set(2.8, 2.4, 4.8);
    const rimLight = new THREE.PointLight(0x1765ff, 14, 16, 2);
    rimLight.position.set(-3.6, -1.4, 1.2);
    const mineralLight = new THREE.PointLight(0x63bdff, 6.5, 12, 2);
    mineralLight.position.set(-1.6, 2.8, 3.4);
    scene.add(ambientLight, keyLight, rimLight, mineralLight);

    const particleCount = compact ? 90 : 180;
    const particlePositions = new Float32Array(particleCount * 3);
    for (let index = 0; index < particleCount; index += 1) {
      const radius = 4 + random() * 8;
      const angle = random() * Math.PI * 2;
      particlePositions[index * 3] = Math.cos(angle) * radius;
      particlePositions[index * 3 + 1] = (random() - 0.5) * 7;
      particlePositions[index * 3 + 2] =
        Math.sin(angle) * radius - random() * 5;
    }
    const particlesGeometry = new THREE.BufferGeometry();
    particlesGeometry.setAttribute(
      "position",
      new THREE.BufferAttribute(particlePositions, 3),
    );
    const particlesMaterial = new THREE.PointsMaterial({
      color: 0x7fd6ff,
      size: compact ? 0.018 : 0.025,
      transparent: true,
      opacity: 0.2,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
    });
    const particles = new THREE.Points(
      particlesGeometry,
      particlesMaterial,
    );
    scene.add(particles);

    const pointer = {
      x: 0,
      y: 0,
      tx: 0,
      ty: 0,
      energy: 0,
      targetEnergy: 0,
      pulse: 0,
    };
    const worldPosition = new THREE.Vector3();
    const projectedPosition = new THREE.Vector3();
    const finePointer = window.matchMedia("(pointer: fine)");
    const saveData = Boolean(
      (
        navigator as Navigator & {
          connection?: { saveData?: boolean };
        }
      ).connection?.saveData,
    );
    const limitedHardware = (navigator.hardwareConcurrency || 8) <= 4;
    let width = 1;
    let height = 1;
    let animationFrame = 0;
    let inViewport = true;
    let documentVisible = !document.hidden;
    let renderedFirstFrame = false;
    let lastFrameAt = performance.now();
    const startedAt = performance.now();
    let reducedMotion =
      document.documentElement.dataset.motionMode === "reduced";
    let guideDeparture = 0;
    let lastGuideOriginX = -1;
    let lastGuideOriginY = -1;
    let lastGuideOriginSignal = 0;

    const resize = () => {
      const bounds = root.getBoundingClientRect();
      width = Math.max(1, bounds.width);
      height = Math.max(1, bounds.height);
      const mobile = width < 760;
      const ratio = Math.min(
        window.devicePixelRatio || 1,
        saveData
          ? 1
          : compact || mobile
            ? 1.2
            : limitedHardware
              ? 1.35
              : 1.65,
      );
      renderer.setPixelRatio(ratio);
      renderer.setSize(width, height, false);
      composer.setPixelRatio(ratio);
      composer.setSize(width, height);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();

      atom.position.x = 0;
      atom.position.y = compact ? 0 : mobile ? -0.86 : -1.04;
      atom.scale.setScalar(compact ? 0.9 : mobile ? 0.86 : 1.18);
    };

    const onPointerMove = (event: PointerEvent) => {
      if (!finePointer.matches || event.pointerType === "touch") return;
      const bounds = root.getBoundingClientRect();
      const inside =
        event.clientX >= bounds.left &&
        event.clientX <= bounds.right &&
        event.clientY >= bounds.top &&
        event.clientY <= bounds.bottom;

      if (!inside) {
        pointer.tx = 0;
        pointer.ty = 0;
        pointer.targetEnergy = 0;
        return;
      }

      pointer.tx = clamp(
        ((event.clientX - bounds.left) / Math.max(bounds.width, 1) - 0.5) * 2,
        -1,
        1,
      );
      pointer.ty = clamp(
        ((event.clientY - bounds.top) / Math.max(bounds.height, 1) - 0.5) * 2,
        -1,
        1,
      );
      const localX =
        (event.clientX - bounds.left) / Math.max(bounds.width, 1);
      const localY =
        (event.clientY - bounds.top) / Math.max(bounds.height, 1);
      const nucleusY = width < 760 ? 0.7 : 0.65;
      const distance = Math.hypot(
        (localX - 0.5) / 0.46,
        (localY - nucleusY) / 0.39,
      );
      pointer.targetEnergy = clamp(1 - distance);
    };

    const onPointerLeave = (event: PointerEvent) => {
      if (event.relatedTarget) return;
      pointer.tx = 0;
      pointer.ty = 0;
      pointer.targetEnergy = 0;
    };

    const onPointerDown = (event: PointerEvent) => {
      const bounds = root.getBoundingClientRect();
      if (
        event.clientX < bounds.left ||
        event.clientX > bounds.right ||
        event.clientY < bounds.top ||
        event.clientY > bounds.bottom
      ) {
        return;
      }
      pointer.pulse = 1;
      ensureAnimation();
    };

    const onMotionMode = (event: Event) => {
      reducedMotion =
        (event as CustomEvent<"full" | "reduced">).detail === "reduced";
      ensureAnimation();
    };

    const onGuideProgress = (event: Event) => {
      guideDeparture = clamp(
        (
          event as CustomEvent<{
            departure?: number;
          }>
        ).detail?.departure ?? 0,
      );
      ensureAnimation();
    };

    const render = (now: number) => {
      animationFrame = 0;
      if (!inViewport || !documentVisible) return;

      const delta = Math.min(0.05, Math.max(0.001, (now - lastFrameAt) / 1000));
      lastFrameAt = now;
      const elapsed = (now - startedAt) / 1000;
      const motionTime = reducedMotion ? 5.4 : elapsed;
      const duration = compact ? 19.6 : 18.4;
      const progress = reducedMotion
        ? 0.64
        : ((elapsed % duration) + duration) % duration / duration;
      const assemble = reducedMotion ? 1 : smoothstep(0, 1.35, elapsed);
      const charge = reducedMotion
        ? 0
        : smoothstep(0.2, 0.35, progress) *
          (1 - smoothstep(0.46, 0.58, progress));
      const opening = reducedMotion
        ? 0.82
        : easeInOutCubic(smoothstep(0.34, 0.5, progress));
      const closing = reducedMotion
        ? 0
        : easeInOutCubic(smoothstep(0.78, 0.95, progress));
      const fracture = reducedMotion ? opening : opening * (1 - closing);
      const clarityEntrance = reducedMotion
        ? 1
        : smoothstep(0.43, 0.56, progress);
      const clarityExit = reducedMotion
        ? 1
        : 1 - smoothstep(0.79, 0.91, progress);
      const clarity = clarityEntrance * clarityExit;
      const ruptureFlash = reducedMotion
        ? 0
        : smoothstep(0.385, 0.435, progress) *
          (1 - smoothstep(0.435, 0.52, progress));
      const flash = ruptureFlash;
      const zoom = easeInOutCubic(clarity);
      const symptomVisibility = reducedMotion
        ? 0
        : assemble *
          clamp(
            1 -
              smoothstep(0.27, 0.45, progress) +
              smoothstep(0.84, 0.97, progress),
          );

      pointer.x += (pointer.tx - pointer.x) * 0.045;
      pointer.y += (pointer.ty - pointer.y) * 0.045;
      pointer.energy += (pointer.targetEnergy - pointer.energy) * 0.075;
      pointer.pulse = Math.max(0, pointer.pulse - delta * 1.7);
      const interactionEnergy = reducedMotion ? 0 : pointer.energy;
      const interactionPulse = reducedMotion ? 0 : pointer.pulse;
      const guideFade = reducedMotion
        ? 1
        : 1 - smootherstep(0.055, 0.3, guideDeparture);

      electronMaterials[0].opacity = guideFade;

      atom.rotation.y =
        motionTime * (reducedMotion ? 0 : 0.075) + pointer.x * 0.28;
      atom.rotation.x = -0.08 + pointer.y * 0.18;
      atom.rotation.z = pointer.x * -0.035;
      energyCore.rotation.y = motionTime * 0.13;
      energyCore.rotation.z = -motionTime * 0.065;
      energyShell.rotation.y = -motionTime * 0.085;
      energyShell.rotation.x = motionTime * 0.045;
      halo.scale.setScalar(
        1 +
          Math.sin(motionTime * 1.35) * 0.025 +
          interactionEnergy * 0.025 +
          interactionPulse * 0.055,
      );
      orbitRoot.rotation.x = pointer.y * 0.055;
      orbitRoot.rotation.y = pointer.x * 0.08;
      particles.rotation.y = motionTime * 0.008;
      particles.position.x = pointer.x * -0.12;
      particles.position.y = pointer.y * 0.08;

      coreUniforms.uTime.value = motionTime;
      coreUniforms.uFracture.value =
        charge * 0.32 +
        fracture * 0.56 +
        interactionEnergy * 0.045 +
        interactionPulse * 0.13;
      coreUniforms.uOpacity.value =
        0.035 +
        charge * 0.12 +
        clarity * 0.84 +
        interactionEnergy * 0.055 +
        interactionPulse * 0.08;
      energyCore.scale.setScalar(
        0.58 +
          charge * 0.06 +
          clarity * 0.36 +
          interactionEnergy * 0.025 +
          interactionPulse * 0.055,
      );
      shellMaterial.opacity =
        (0.006 +
          charge * 0.14 +
          interactionEnergy * 0.035 +
          interactionPulse * 0.06) *
        (1 - fracture * 0.88);
      haloMaterial.opacity =
        0.006 +
        charge * 0.016 +
        clarity * 0.024 +
        interactionEnergy * 0.012 +
        interactionPulse * 0.018;

      nucleonMaterials.forEach((material, index) => {
        const baseIntensity = index === 2 ? 0.05 : index === 1 ? 0.07 : 0.08;
        material.emissiveIntensity =
          baseIntensity +
          charge * 0.2 +
          ruptureFlash * 0.28 +
          interactionEnergy * 0.08 +
          interactionPulse * 0.16;
      });

      nucleons.forEach((nucleon, index) => {
        const introduction = clamp(
          (assemble - index / nucleons.length * 0.14) / 0.86,
        );
        const introScale = lerp(0.02, 1, smoothstep(0, 1, introduction));
        nucleon.mesh.position
          .copy(nucleon.base)
          .multiplyScalar(lerp(1.3, 1, introduction))
          .addScaledVector(nucleon.fracture, fracture)
          .addScaledVector(
            nucleon.outward,
            interactionEnergy * (0.018 + (index % 4) * 0.003) +
              interactionPulse * (0.055 + (index % 5) * 0.006),
          );
        const scale =
          introScale *
          (0.82 + (index % 7) * 0.038) *
          (1 - fracture * 0.08);
        nucleon.mesh.scale.set(
          nucleon.shape.x * scale,
          nucleon.shape.y * scale,
          nucleon.shape.z * scale,
        );
        if (!reducedMotion) {
          nucleon.mesh.rotation.x += nucleon.spin.x * 0.0025;
          nucleon.mesh.rotation.y += nucleon.spin.y * 0.0025;
          nucleon.mesh.rotation.z += nucleon.spin.z * 0.0025;
        }
      });

      orbitRoot.scale.setScalar(0.9 + clarity * 0.1);
      orbits.forEach((orbit, index) => {
        const angle = motionTime * orbit.speed + orbit.phase;
        const radiusX = 1.88 + index * 0.18;
        const radiusY = radiusX * (0.44 + index * 0.024);
        orbit.electron.position.set(
          Math.cos(angle) * radiusX,
          Math.sin(angle) * radiusY,
          0,
        );
        const guideSourceBoost =
          index === 0
            ? smootherstep(0.012, 0.08, guideDeparture) *
              (1 - smootherstep(0.2, 0.34, guideDeparture))
            : 0;
        const visibleAmount = Math.max(clarity, guideSourceBoost);
        const sourceFade = index === 0 ? guideFade : 1;
        orbit.electron.scale.setScalar(
          lerp(0.01, 1, visibleAmount) *
            lerp(0.04, 1, smootherstep(0, 1, sourceFade)),
        );
        orbit.lineMaterial.opacity =
          (compact ? 0.09 : 0.13) * visibleAmount;

        const shouldProject =
          index === 0 || Boolean(labelRefs.current[index] && !compact);
        if (shouldProject) {
          orbit.electron.getWorldPosition(worldPosition);
          projectedPosition.copy(worldPosition).project(camera);
          const rawLabelX = (projectedPosition.x * 0.5 + 0.5) * width;
          const rawLabelY = (-projectedPosition.y * 0.5 + 0.5) * height;
          if (index === 0 && guideDeparture < 0.26) {
            const originX = clamp(rawLabelX / Math.max(width, 1));
            const originY = clamp(rawLabelY / Math.max(height, 1));
            if (
              now - lastGuideOriginSignal > 34 &&
              (Math.abs(originX - lastGuideOriginX) > 0.001 ||
                Math.abs(originY - lastGuideOriginY) > 0.001)
            ) {
              lastGuideOriginX = originX;
              lastGuideOriginY = originY;
              lastGuideOriginSignal = now;
              window.dispatchEvent(
                new CustomEvent("nuc-guide-origin", {
                  detail: { x: originX, y: originY },
                }),
              );
            }
          }

          const label = labelRefs.current[index];
          if (!label || compact) return;
          const labelX = clamp(
            rawLabelX,
            width < 760 ? 42 : 120,
            width - (width < 760 ? 132 : 210),
          );
          const labelY = clamp(
            rawLabelY,
            width < 760 ? 150 : 80,
            height - (width < 760 ? 155 : 80),
          );
          const labelOpacity =
            visibleAmount *
            (projectedPosition.z > -1 && projectedPosition.z < 1 ? 1 : 0);
          label.style.transform = `translate3d(${labelX}px, ${labelY}px, 0)`;
          label.style.opacity = `${labelOpacity}`;
        }
      });

      camera.position.z = lerp(
        compact ? 7.45 : 7.8,
        compact ? 6.35 : 5.75,
        zoom,
      );
      camera.position.x = pointer.x * 0.24;
      camera.position.y = 0.08 - pointer.y * 0.15;
      camera.lookAt(0, 0, 0);
      bloomPass.strength =
        (compact ? 0.25 : 0.29) +
        charge * 0.07 +
        clarity * 0.1 +
        ruptureFlash * 0.24 +
        interactionEnergy * 0.075 +
        interactionPulse * 0.14;
      keyLight.intensity =
        13 +
        charge * 4 +
        clarity * 3 +
        ruptureFlash * 8 +
        interactionEnergy * 2.5 +
        interactionPulse * 5;
      keyLight.position.x = 2.8 + pointer.x * 1.4;
      keyLight.position.y = 2.4 - pointer.y * 0.9;
      rimLight.intensity =
        8 +
        charge * 4 +
        clarity * 4 +
        interactionEnergy * 2 +
        interactionPulse * 3;
      rimLight.position.x = -3.6 - pointer.x * 0.8;
      rimLight.position.y = -1.4 + pointer.y * 0.6;
      root.style.setProperty(
        "--atomic-flash",
        `${Math.max(flash, interactionPulse * 0.12)}`,
      );
      root.style.setProperty("--atomic-fracture", `${fracture}`);
      root.style.setProperty(
        "--atomic-charge",
        `${charge * (1 - fracture * 0.86)}`,
      );
      root.style.setProperty("--atomic-clarity", `${clarity}`);
      root.style.setProperty("--atomic-symptoms", `${symptomVisibility}`);
      root.style.setProperty(
        "--atomic-pointer-energy",
        `${interactionEnergy}`,
      );
      root.style.setProperty("--atomic-pointer-pulse", `${interactionPulse}`);

      composer.render();
      if (!renderedFirstFrame) {
        renderedFirstFrame = true;
        setReady(true);
      }
      if (!reducedMotion) {
        animationFrame = requestAnimationFrame(render);
      }
    };

    const ensureAnimation = () => {
      if (inViewport && documentVisible && animationFrame === 0) {
        animationFrame = requestAnimationFrame(render);
      }
    };

    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(root);
    const intersectionObserver = new IntersectionObserver(
      ([entry]) => {
        inViewport = entry.isIntersecting;
        if (!inViewport && animationFrame) {
          cancelAnimationFrame(animationFrame);
          animationFrame = 0;
        }
        ensureAnimation();
      },
      { rootMargin: "160px" },
    );
    intersectionObserver.observe(root);

    const onVisibility = () => {
      documentVisible = !document.hidden;
      if (!documentVisible && animationFrame) {
        cancelAnimationFrame(animationFrame);
        animationFrame = 0;
      }
      ensureAnimation();
    };

    const onContextLost = (event: Event) => {
      event.preventDefault();
      root.classList.add("has-fallback");
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
        animationFrame = 0;
      }
    };

    resize();
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    window.addEventListener("pointerout", onPointerLeave, { passive: true });
    window.addEventListener("pointerdown", onPointerDown, { passive: true });
    window.addEventListener("nuc-motion-change", onMotionMode);
    window.addEventListener("nuc-guide-progress", onGuideProgress);
    document.addEventListener("visibilitychange", onVisibility);
    canvas.addEventListener("webglcontextlost", onContextLost);
    ensureAnimation();

    return () => {
      if (animationFrame) cancelAnimationFrame(animationFrame);
      resizeObserver.disconnect();
      intersectionObserver.disconnect();
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerout", onPointerLeave);
      window.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("nuc-motion-change", onMotionMode);
      window.removeEventListener("nuc-guide-progress", onGuideProgress);
      document.removeEventListener("visibilitychange", onVisibility);
      canvas.removeEventListener("webglcontextlost", onContextLost);
      coreGeometry.dispose();
      coreMaterial.dispose();
      shellGeometry.dispose();
      shellMaterial.dispose();
      nucleonGeometry.dispose();
      nucleonMaterials.forEach((material) => material.dispose());
      electronGeometry.dispose();
      electronMaterials.forEach((material) => material.dispose());
      orbits.forEach((orbit) => {
        const line = orbit.group.children[0] as THREE.Line;
        line.geometry.dispose();
        orbit.lineMaterial.dispose();
      });
      haloGeometry.dispose();
      haloMaterial.dispose();
      particlesGeometry.dispose();
      particlesMaterial.dispose();
      composer.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
    };
  }, [compact]);

  return (
    <div
      ref={rootRef}
      className={`nucleus-scene atomic-nucleus-scene ${compact ? "is-compact" : ""} ${ready ? "is-ready" : ""}`}
    >
      <div className="atomic-css-fallback" aria-hidden="true">
        <i />
        <i />
        <i />
      </div>
      <canvas
        ref={canvasRef}
        className="nucleus-canvas"
        role="img"
        aria-label="Uma crosta física reúne sintomas da operação. A energia se concentra, a superfície se rompe e revela um núcleo tridimensional cercado pelas causas Estrutura comercial, Processos operacionais, Gestão e responsabilidades e Marketing e aquisição. Uma nova eclosão reinicia o ciclo."
      />
      {!compact && (
        <>
          <div className="atomic-symptom-labels" aria-hidden="true">
            {SYMPTOMS.map((symptom, index) => (
              <span key={symptom} data-index={index + 1}>
                {symptom}
                <i />
              </span>
            ))}
          </div>
          <div className="atomic-labels atomic-cause-labels" aria-hidden="true">
            {CAUSES.map((cause, index) => (
              <span
                key={cause}
                ref={(element) => {
                  labelRefs.current[index] = element;
                }}
              >
                <i />
                {cause}
              </span>
            ))}
          </div>
        </>
      )}
      <div className="atomic-charge-ring" aria-hidden="true" />
      <div className="atomic-flash" aria-hidden="true" />
    </div>
  );
}
