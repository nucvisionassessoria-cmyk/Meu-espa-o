"use client";

import { useEffect, useRef } from "react";

type MotionMode = "full" | "reduced";

type RoutePoint = {
  x: number;
  y: number;
};

const clamp = (value: number, min = 0, max = 1) =>
  Math.min(max, Math.max(min, value));

const smoothstep = (from: number, to: number, value: number) => {
  const progress = clamp((value - from) / Math.max(to - from, 0.0001));
  return progress * progress * (3 - 2 * progress);
};

const smootherstep = (from: number, to: number, value: number) => {
  const progress = clamp((value - from) / Math.max(to - from, 0.0001));
  return (
    progress *
    progress *
    progress *
    (progress * (progress * 6 - 15) + 10)
  );
};

const mix = (from: number, to: number, progress: number) =>
  from + (to - from) * progress;

const damp = (
  current: number,
  target: number,
  response: number,
  delta: number,
) => mix(current, target, 1 - Math.exp(-response * delta));

const quadratic = (
  from: number,
  control: number,
  to: number,
  progress: number,
) => {
  const inverse = 1 - progress;
  return (
    inverse * inverse * from +
    2 * inverse * progress * control +
    progress * progress * to
  );
};

const cubic = (
  from: number,
  controlFrom: number,
  controlTo: number,
  to: number,
  progress: number,
) => {
  const inverse = 1 - progress;
  return (
    inverse * inverse * inverse * from +
    3 * inverse * inverse * progress * controlFrom +
    3 * inverse * progress * progress * controlTo +
    progress * progress * progress * to
  );
};

export default function EnergyGuide({
  motionMode,
}: {
  motionMode: MotionMode;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || motionMode === "reduced") return;

    const context = canvas.getContext("2d");
    const hero = document.querySelector<HTMLElement>(".hero");
    const nucleusElement =
      document.querySelector<HTMLElement>(".atomic-nucleus-scene");
    const contact = document.querySelector<HTMLElement>(".contact-section");
    const globe = document.querySelector<HTMLElement>(
      ".contact-atmosphere > div",
    );
    const form = document.querySelector<HTMLElement>(".form-shell");

    if (!context || !hero || !nucleusElement || !contact || !globe || !form) {
      return;
    }

    let viewportWidth = window.innerWidth;
    let viewportHeight = window.innerHeight;
    const saveData = Boolean(
      (
        navigator as Navigator & {
          connection?: { saveData?: boolean };
        }
      ).connection?.saveData,
    );
    const lowPower =
      saveData ||
      window.innerWidth < 700 ||
      (navigator.hardwareConcurrency || 8) <= 4;
    const finePointer = window.matchMedia("(pointer: fine)");
    let pixelRatio = Math.min(
      window.devicePixelRatio || 1,
      lowPower ? 1.15 : 1.4,
    );
    let frame = 0;
    let documentVisible = !document.hidden;
    let lastPaintAt = 0;
    let previousTime = performance.now();
    let previousScroll = window.scrollY;
    let scrollVelocity = 0;
    let routeScroll = window.scrollY;
    let routeScrollVelocity = 0;
    let latchedStartX = viewportWidth * 0.5;
    let latchedStartY = viewportHeight * 0.67;
    let canLatchDeparture = true;
    let impactAnchorX = viewportWidth * 0.58;
    let impactAnchorY = viewportHeight * 0.62;
    let impactAnchorReady = false;
    let freezeImpactAnchor = false;
    let travelDirection: 1 | -1 = 1;
    let pointerX = -1000;
    let pointerY = -1000;
    let pointerVisible = false;
    let evadeX = 0;
    let evadeY = 0;
    let evadeVelocityX = 0;
    let evadeVelocityY = 0;
    let evadeTargetX = 0;
    let evadeTargetY = 0;
    let evadeHoldUntil = 0;
    let evadeSide = 1;
    let pointerWasNear = false;
    let nucleusOriginX = 0.5;
    let nucleusOriginY = 0.67;
    let impactArmed = true;
    let impactTimer = 0;
    let lastDeparture = -1;
    let lastMerge = -1;
    let orbVisibility = 0;
    let orbScale = 0.05;

    const resize = () => {
      viewportWidth = window.innerWidth;
      viewportHeight = window.innerHeight;
      pixelRatio = Math.min(
        window.devicePixelRatio || 1,
        lowPower ? 1.15 : 1.4,
      );
      canvas.width = Math.max(1, Math.round(viewportWidth * pixelRatio));
      canvas.height = Math.max(1, Math.round(viewportHeight * pixelRatio));
      canvas.style.width = `${viewportWidth}px`;
      canvas.style.height = `${viewportHeight}px`;
      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    };

    const signalProgress = (departure: number, merge: number) => {
      if (
        Math.abs(departure - lastDeparture) < 0.008 &&
        Math.abs(merge - lastMerge) < 0.008
      ) {
        return;
      }

      lastDeparture = departure;
      lastMerge = merge;
      window.dispatchEvent(
        new CustomEvent("nuc-guide-progress", {
          detail: { departure, merge },
        }),
      );
    };

    const receiveNucleusOrigin = (event: Event) => {
      const detail = (
        event as CustomEvent<{
          x?: number;
          y?: number;
        }>
      ).detail;

      if (
        typeof detail?.x !== "number" ||
        typeof detail?.y !== "number"
      ) {
        return;
      }

      nucleusOriginX = clamp(detail.x);
      nucleusOriginY = clamp(detail.y);
    };

    const onPointerMove = (event: PointerEvent) => {
      if (!finePointer.matches || event.pointerType === "touch") return;
      pointerX = event.clientX;
      pointerY = event.clientY;
      pointerVisible = true;
    };

    const onPointerLeave = () => {
      pointerVisible = false;
      pointerX = -1000;
      pointerY = -1000;
    };

    const triggerImpact = () => {
      contact.classList.remove("is-orb-impact");
      void contact.offsetWidth;
      contact.classList.add("is-orb-impact");
      window.clearTimeout(impactTimer);
      impactTimer = window.setTimeout(
        () => contact.classList.remove("is-orb-impact"),
        1250,
      );
    };

    const drawRouteTrail = (
      route: RoutePoint[],
      alpha: number,
      radius: number,
      elapsed: number,
    ) => {
      if (route.length < 2 || alpha <= 0.002) return;

      const head = route[0];
      const tail = route[route.length - 1];
      const speedEnergy = clamp(Math.abs(scrollVelocity) / 1800);
      const lineEnergy = mix(0.64, 0.92, speedEnergy);
      const gradient = context.createLinearGradient(
        head.x,
        head.y,
        tail.x,
        tail.y,
      );
      gradient.addColorStop(
        0,
        `rgba(138, 217, 255, ${alpha * lineEnergy * 0.72})`,
      );
      gradient.addColorStop(
        0.22,
        `rgba(49, 133, 244, ${alpha * lineEnergy * 0.46})`,
      );
      gradient.addColorStop(
        0.66,
        `rgba(22, 69, 173, ${alpha * lineEnergy * 0.2})`,
      );
      gradient.addColorStop(1, "rgba(8, 29, 82, 0)");

      const tracePath = () => {
        context.beginPath();
        context.moveTo(head.x, head.y);
        for (let index = 1; index < route.length - 1; index += 1) {
          const point = route[index];
          const next = route[index + 1];
          context.quadraticCurveTo(
            point.x,
            point.y,
            (point.x + next.x) * 0.5,
            (point.y + next.y) * 0.5,
          );
        }
        context.lineTo(tail.x, tail.y);
      };

      context.save();
      context.globalCompositeOperation = "lighter";
      context.lineCap = "round";
      context.lineJoin = "round";

      tracePath();
      context.strokeStyle = gradient;
      context.lineWidth = radius * (lowPower ? 1.05 : 1.35);
      context.shadowBlur = radius * (lowPower ? 1.4 : 2.1);
      context.shadowColor = "rgba(29, 101, 222, 0.5)";
      context.globalAlpha = 0.42;
      context.stroke();

      tracePath();
      context.lineWidth = lowPower ? 0.9 : 1.05;
      context.shadowBlur = lowPower ? 3 : 5;
      context.shadowColor = "rgba(151, 224, 255, 0.6)";
      context.globalAlpha = 0.9;
      context.stroke();

      route.forEach((point, index) => {
        if (index === 0 || index % (lowPower ? 7 : 4) !== 0) return;
        const life = Math.pow(1 - index / route.length, 1.15);
        const shimmer =
          0.42 + Math.sin(elapsed * 0.004 + index * 1.61) * 0.28;
        const drift = Math.sin(elapsed * 0.0017 + index * 2.3) * radius * 0.42;
        context.beginPath();
        context.arc(
          point.x + drift,
          point.y + Math.cos(index * 1.41) * radius * 0.2,
          (0.45 + (index % 3) * 0.22) * life,
          0,
          Math.PI * 2,
        );
        context.fillStyle = `rgba(133, 211, 245, ${
          life * shimmer * alpha * 0.58
        })`;
        context.fill();
      });

      context.restore();
    };

    const drawOrb = (
      x: number,
      y: number,
      radius: number,
      alpha: number,
      elapsed: number,
      merge: number,
      emergence: number,
    ) => {
      if (alpha <= 0.002 || radius <= 0.2) return;

      const pulse = 1 + Math.sin(elapsed * 0.0038) * 0.04;
      const energy = 1 + Math.sin(elapsed * 0.0067) * 0.045;
      const auraPresence = smootherstep(0.12, 0.94, emergence);
      const materialPresence = smootherstep(0.2, 0.82, emergence);

      context.save();
      context.globalCompositeOperation = "lighter";
      context.globalAlpha = alpha;

      const aura = context.createRadialGradient(
        x,
        y,
        radius * 0.12,
        x,
        y,
        radius * 4.25 * pulse,
      );
      aura.addColorStop(0, `rgba(174, 229, 248, ${0.46 * auraPresence})`);
      aura.addColorStop(0.18, `rgba(55, 139, 222, ${0.33 * auraPresence})`);
      aura.addColorStop(0.5, `rgba(20, 69, 175, ${0.14 * auraPresence})`);
      aura.addColorStop(1, "rgba(5, 26, 93, 0)");
      context.fillStyle = aura;
      context.beginPath();
      context.arc(x, y, radius * 4.25 * pulse, 0, Math.PI * 2);
      context.fill();

      context.strokeStyle = `rgba(120, 215, 255, ${
        (0.12 + Math.sin(elapsed * 0.004) * 0.035) * auraPresence
      })`;
      context.lineWidth = 0.7;
      context.beginPath();
      context.ellipse(
        x,
        y,
        radius * 1.58 * energy,
        radius * 0.68,
        elapsed * 0.00034,
        0,
        Math.PI * 2,
      );
      context.stroke();

      const sphere = context.createRadialGradient(
        x - radius * 0.34,
        y - radius * 0.4,
        radius * 0.06,
        x,
        y,
        radius * 1.08,
      );
      sphere.addColorStop(0, "rgba(218, 244, 250, 0.98)");
      sphere.addColorStop(0.16, "rgba(104, 188, 225, 0.98)");
      sphere.addColorStop(0.46, "rgba(30, 94, 190, 0.99)");
      sphere.addColorStop(0.8, "rgba(8, 38, 116, 0.99)");
      sphere.addColorStop(1, "rgba(2, 15, 55, 0.98)");
      context.fillStyle = sphere;
      context.shadowBlur =
        radius * (0.65 + materialPresence + merge * 0.85);
      context.shadowColor = "rgba(48, 135, 218, 0.76)";
      context.beginPath();
      context.arc(x, y, radius * energy, 0, Math.PI * 2);
      context.fill();

      context.globalCompositeOperation = "source-over";
      context.fillStyle = `rgba(225, 247, 251, ${
        0.7 * materialPresence
      })`;
      context.beginPath();
      context.ellipse(
        x - radius * 0.29,
        y - radius * 0.36,
        radius * 0.2,
        radius * 0.11,
        -0.55,
        0,
        Math.PI * 2,
      );
      context.fill();
      context.restore();
    };

    const render = (time: number) => {
      frame = 0;
      if (!documentVisible) return;

      if (lowPower && time - lastPaintAt < 30) {
        frame = window.requestAnimationFrame(render);
        return;
      }
      lastPaintAt = time;

      const delta = Math.min(0.05, Math.max(0.001, (time - previousTime) / 1000));
      previousTime = time;

      const scrollDelta = window.scrollY - previousScroll;
      previousScroll = window.scrollY;
      scrollVelocity +=
        (scrollDelta / Math.max(delta, 0.001) - scrollVelocity) * 0.16;
      scrollVelocity *= 0.92;

      const heroBounds = hero.getBoundingClientRect();
      const nucleusBounds = nucleusElement.getBoundingClientRect();
      const contactBounds = contact.getBoundingClientRect();
      const globeBounds = globe.getBoundingClientRect();
      const formBounds = form.getBoundingClientRect();
      const compact = viewportWidth < 700;

      const pageScroll = window.scrollY;
      const heroTop = pageScroll + heroBounds.top;
      const contactTop = pageScroll + contactBounds.top;
      const departureStart =
        heroTop + heroBounds.height * (compact ? 0.025 : 0.035);
      const departureEnd =
        heroTop + heroBounds.height * (compact ? 0.86 : 0.9);
      const mergeStart = Math.max(
        departureEnd + viewportHeight,
        contactTop - viewportHeight * 0.94,
      );
      const mergeEnd = Math.max(
        mergeStart + viewportHeight * 0.42,
        contactTop - viewportHeight * 0.24,
      );
      /*
       * One scalar clock drives the whole journey. The previous implementation
       * softened scroll progress and then used a second 2D spring to chase the
       * resulting point. On fast scrolls that second spring cut across curves,
       * which read as a teleport. Following document progress here keeps every
       * rendered position on the authored route, in both directions.
       */
      const routeError = pageScroll - routeScroll;
      const routeUrgency = clamp(
        Math.abs(routeError) / Math.max(viewportHeight * 1.35, 1),
      );
      const routeStiffness = mix(9.5, 15.5, routeUrgency);
      const routeDamping =
        2 * Math.sqrt(routeStiffness) * mix(1.22, 1.08, routeUrgency);
      routeScrollVelocity += routeError * routeStiffness * delta;
      routeScrollVelocity *= Math.exp(-routeDamping * delta);
      const routeSpeedLimit =
        viewportHeight *
        mix(compact ? 1.25 : 1.45, compact ? 2.35 : 2.75, routeUrgency);
      routeScrollVelocity = clamp(
        routeScrollVelocity,
        -routeSpeedLimit,
        routeSpeedLimit,
      );
      const routeStep = routeScrollVelocity * delta;
      if (
        Math.abs(routeError) < 0.06 ||
        (routeError !== 0 &&
          Math.sign(routeStep) === Math.sign(routeError) &&
          Math.abs(routeStep) >= Math.abs(routeError))
      ) {
        routeScroll = pageScroll;
        routeScrollVelocity = 0;
      } else {
        routeScroll += routeStep;
      }

      if (Math.abs(routeScrollVelocity) > 1.5) {
        travelDirection = routeScrollVelocity > 0 ? 1 : -1;
      }

      const departure = smootherstep(
        departureStart,
        departureEnd,
        routeScroll,
      );
      const merge = smootherstep(mergeStart, mergeEnd, routeScroll);

      const liveStartX =
        nucleusBounds.left + nucleusBounds.width * nucleusOriginX;
      const liveStartY =
        nucleusBounds.top + nucleusBounds.height * nucleusOriginY;

      const rawDeparture = smootherstep(
        departureStart,
        departureEnd,
        pageScroll,
      );

      if (departure <= 0.002 && rawDeparture <= 0.002) {
        canLatchDeparture = true;
        latchedStartX = liveStartX;
        latchedStartY = liveStartY;
      } else if (canLatchDeparture) {
        canLatchDeparture = false;
        latchedStartX = liveStartX;
        latchedStartY = liveStartY + (scrollDelta > 0 ? scrollDelta : 0);
      }

      const startX = latchedStartX;
      const startY = latchedStartY;
      const dockX = compact
        ? 21
        : clamp(viewportWidth * 0.038, 38, 68);
      const dockY = viewportHeight * 0.5;
      const departEase = smootherstep(0, 1, departure);

      const releaseEnd = 0.32;
      const releaseX = startX - viewportWidth * (compact ? 0.045 : 0.036);
      const releaseY = Math.min(
        viewportHeight * 0.84,
        startY + viewportHeight * (compact ? 0.085 : 0.115),
      );

      const departurePoint = (progress: number): RoutePoint => {
        let x: number;
        let y: number;

        if (progress <= releaseEnd) {
          const releaseProgress = smootherstep(0, releaseEnd, progress);
          x = cubic(
            startX,
            startX - viewportWidth * 0.006,
            startX - viewportWidth * 0.022,
            releaseX,
            releaseProgress,
          );
          y = cubic(
            startY,
            startY + viewportHeight * 0.018,
            startY + viewportHeight * 0.07,
            releaseY,
            releaseProgress,
          );
        } else {
          const travelProgress = smootherstep(releaseEnd, 1, progress);
          x = cubic(
            releaseX,
            viewportWidth * (compact ? 0.42 : 0.38),
            dockX + viewportWidth * (compact ? 0.095 : 0.11),
            dockX,
            travelProgress,
          );
          y = cubic(
            releaseY,
            Math.min(
              viewportHeight * 0.9,
              releaseY + viewportHeight * 0.055,
            ),
            dockY - viewportHeight * 0.09,
            dockY,
            travelProgress,
          );
        }

        const windEnvelope = Math.pow(
          Math.max(0, Math.sin(Math.PI * progress)),
          1.25,
        );
        const windStrength = compact ? 0.68 : 1;
        x +=
          (Math.sin(progress * Math.PI * 4.6 + 0.35) *
            viewportWidth *
            0.0048 +
            Math.sin(progress * Math.PI * 9.2 + 1.1) *
              viewportWidth *
              0.0014) *
          windEnvelope *
          windStrength;
        y +=
          (Math.sin(progress * Math.PI * 5.15 + 0.9) *
            viewportHeight *
            0.0042 +
            Math.sin(progress * Math.PI * 10.4) *
              viewportHeight *
              0.0012) *
          windEnvelope *
          windStrength;

        return { x, y };
      };

      /*
       * The side route is a function of the document position instead of a
       * short frame history. That makes the route reversible: a fast upward
       * scroll returns through the exact energy trace previously used below.
       */
      const cruisePoint = (scrollPosition: number): RoutePoint => {
        const progress = smoothstep(
          departureEnd,
          mergeStart,
          scrollPosition,
        );
        const envelope = Math.pow(
          Math.max(0, Math.sin(Math.PI * progress)),
          0.72,
        );
        const phase =
          (scrollPosition - departureEnd) / Math.max(viewportHeight, 1);

        return {
          x:
            dockX +
            envelope *
              (Math.sin(phase * 4.45 + 0.65) * (compact ? 8 : 15) +
                Math.sin(phase * 9.7 + 1.3) * (compact ? 2.2 : 4.3)),
          y:
            dockY +
            envelope *
              (Math.sin(phase * 3.7 + 0.25) *
                viewportHeight *
                (compact ? 0.028 : 0.038) +
                Math.sin(phase * 8.4 + 1.1) *
                  viewportHeight *
                  (compact ? 0.007 : 0.01)),
        };
      };

      const departPosition = departurePoint(departEase);
      const cruisePosition = cruisePoint(routeScroll);
      const cruiseBlend = smoothstep(0.9, 1, departEase);
      const guideX = mix(departPosition.x, cruisePosition.x, cruiseBlend);
      const guideY = mix(departPosition.y, cruisePosition.y, cruiseBlend);

      const globeCenterX = globeBounds.left + globeBounds.width * 0.5;
      const globeCenterY = globeBounds.top + globeBounds.height * 0.5;
      const globeRadius =
        Math.min(globeBounds.width, globeBounds.height) * 0.5;
      const desiredImpactX =
        formBounds.left + formBounds.width * (compact ? 0.53 : 0.57);
      const liveImpactX = clamp(
        desiredImpactX,
        globeCenterX - globeRadius * 0.82,
        globeCenterX + globeRadius * 0.82,
      );
      const horizontalImpact = liveImpactX - globeCenterX;
      const liveImpactY =
        globeCenterY -
        Math.sqrt(
          Math.max(
            0,
            globeRadius * globeRadius -
              horizontalImpact * horizontalImpact,
          ),
        ) +
        (compact ? 5 : 8);

      if (!impactAnchorReady) {
        impactAnchorX = liveImpactX;
        impactAnchorY = liveImpactY;
        impactAnchorReady = true;
      }

      /*
       * While approaching, the endpoint can gently follow the globe. The first
       * upward scroll freezes the exact contact point so the orb emerges from
       * where it disappeared instead of being reassigned to the globe's new
       * post-scroll coordinates.
       */
      if (scrollDelta < -0.08 && merge > 0.04) {
        freezeImpactAnchor = true;
      } else if (merge <= 0.012 && pageScroll < mergeStart) {
        freezeImpactAnchor = false;
      }

      if (!freezeImpactAnchor) {
        const anchorResponse = merge > 0.82 ? 4.8 : 3.2;
        impactAnchorX = damp(
          impactAnchorX,
          liveImpactX,
          anchorResponse,
          delta,
        );
        impactAnchorY = damp(
          impactAnchorY,
          liveImpactY,
          anchorResponse,
          delta,
        );
      }

      const impactX = impactAnchorX;
      const impactY = impactAnchorY;
      const mergeEase = smootherstep(0, 1, merge);
      const mergePoint = (progress: number): RoutePoint => ({
        x: quadratic(
          dockX,
          Math.max(dockX + viewportWidth * 0.12, viewportWidth * 0.24),
          impactX,
          progress,
        ),
        y: quadratic(
          dockY,
          Math.min(dockY, viewportHeight * 0.42),
          impactY,
          progress,
        ),
      });
      const mergePosition = mergePoint(mergeEase);
      const baseDesiredX = mix(guideX, mergePosition.x, mergeEase);
      const baseDesiredY = mix(guideY, mergePosition.y, mergeEase);

      /*
       * A decorative guide may be playful because it is not a control. It
       * evades a fine pointer only on the side route, then springs back to the
       * same deterministic path without affecting the departure or arrival.
       */
      const canEvade =
        finePointer.matches &&
        pointerVisible &&
        departEase > 0.96 &&
        merge < 0.68;
      const probeX = baseDesiredX + evadeX;
      const probeY = baseDesiredY + evadeY;
      const pointerDistance = Math.hypot(probeX - pointerX, probeY - pointerY);
      const evadeRange = compact ? 0 : 104;
      const pointerNear = canEvade && pointerDistance < evadeRange;

      if (pointerNear) {
        if (!pointerWasNear) evadeSide *= -1;
        pointerWasNear = true;

        const safeDistance = Math.max(pointerDistance, 0.001);
        const awayX = (probeX - pointerX) / safeDistance;
        const awayY = (probeY - pointerY) / safeDistance;
        const pressure = Math.pow(1 - pointerDistance / evadeRange, 0.7);
        const leap = 42 + pressure * 68;
        const tangentX = -awayY * evadeSide;
        const tangentY = awayX * evadeSide;
        const corridorMinX = 18;
        const corridorMaxX = Math.min(viewportWidth * 0.18, 190);
        const candidateX = clamp(
          probeX + (awayX * 0.78 + tangentX * 0.5) * leap,
          corridorMinX,
          corridorMaxX,
        );
        const candidateY = clamp(
          probeY + (awayY * 0.72 + tangentY * 0.62) * leap,
          92,
          viewportHeight - 82,
        );

        evadeTargetX = candidateX - baseDesiredX;
        evadeTargetY = candidateY - baseDesiredY;
        evadeHoldUntil = time + 340;
      } else if (pointerDistance > evadeRange * 1.24) {
        pointerWasNear = false;
      }

      if (!canEvade || time > evadeHoldUntil) {
        evadeTargetX = 0;
        evadeTargetY = 0;
      }

      const evadeStiffness = pointerNear ? 155 : 66;
      const evadeDamping = pointerNear ? 18 : 14;
      evadeVelocityX += (evadeTargetX - evadeX) * evadeStiffness * delta;
      evadeVelocityY += (evadeTargetY - evadeY) * evadeStiffness * delta;
      const evadeDrag = Math.exp(-evadeDamping * delta);
      evadeVelocityX *= evadeDrag;
      evadeVelocityY *= evadeDrag;
      evadeX += evadeVelocityX * delta;
      evadeY += evadeVelocityY * delta;

      const currentX = baseDesiredX + evadeX;
      const currentY = baseDesiredY + evadeY;

      const route: RoutePoint[] = [{ x: currentX, y: currentY }];
      const routeSamples = lowPower ? 28 : 48;

      if (mergeEase > 0.001) {
        const span = compact ? 0.68 : 0.82;
        for (let index = 1; index < routeSamples; index += 1) {
          const distance = index / (routeSamples - 1);
          const progress = clamp(
            mergeEase - travelDirection * distance * span,
          );
          route.push(mergePoint(progress));
        }
      } else if (departEase < 0.999) {
        const span = compact ? 0.82 : 0.92;
        for (let index = 1; index < routeSamples; index += 1) {
          const distance = index / (routeSamples - 1);
          const progress = clamp(
            departEase - travelDirection * distance * span,
          );
          route.push(departurePoint(progress));
        }
      } else {
        const scrollSpan = viewportHeight * (compact ? 0.94 : 1.18);
        for (let index = 1; index < routeSamples; index += 1) {
          const distance = index / (routeSamples - 1);
          const sampleScroll = clamp(
            routeScroll - travelDirection * distance * scrollSpan,
            departureEnd,
            mergeStart,
          );
          const point = cruisePoint(sampleScroll);
          route.push({
            x: point.x,
            y:
              point.y +
              (sampleScroll - routeScroll) * (compact ? 0.58 : 0.68),
          });
        }
      }

      if (merge < 0.72) impactArmed = true;
      const impactDistance = Math.hypot(
        impactX - currentX,
        impactY - currentY,
      );
      if (
        merge > 0.9 &&
        impactDistance < (compact ? 34 : 46) &&
        impactArmed &&
        scrollVelocity >= -12
      ) {
        impactArmed = false;
        triggerImpact();
      }

      signalProgress(departure, merge);

      const emergence = smootherstep(0.035, 0.36, departure);
      const trailEmergence = smootherstep(0.14, 0.43, departure);
      const arrived =
        1 -
        smootherstep(
          compact ? 7 : 9,
          compact ? 42 : 58,
          impactDistance,
        );
      const absorptionDepth =
        smootherstep(0.7, 1, merge) *
        smootherstep(0.08, 0.96, arrived);
      const visibilityTarget =
        Math.pow(emergence, 1.12) * (1 - absorptionDepth);
      const visibilityResponse =
        visibilityTarget > orbVisibility
          ? merge > 0.64
            ? 2.35
            : 2.75
          : 3.15;
      orbVisibility = damp(
        orbVisibility,
        visibilityTarget,
        visibilityResponse,
        delta,
      );

      const baseRadius = compact ? 5.8 : clamp(viewportWidth * 0.0048, 6.5, 9);
      const scaleTarget =
        mix(0.045, 1, smootherstep(0.06, 0.96, emergence)) *
        mix(1, 0.1, absorptionDepth);
      orbScale = damp(
        orbScale,
        scaleTarget,
        scaleTarget > orbScale ? 2.65 : 3.35,
        delta,
      );
      const alpha = clamp(orbVisibility);
      const radius = baseRadius * Math.max(0.035, orbScale);
      const trailReturn = 1 - smootherstep(0.91, 1, merge);

      context.clearRect(0, 0, viewportWidth, viewportHeight);
      drawRouteTrail(
        route,
        alpha * trailEmergence * trailReturn,
        baseRadius,
        time,
      );
      drawOrb(
        currentX,
        currentY,
        radius,
        alpha,
        time,
        merge,
        clamp(emergence * mix(0.72, 1, orbVisibility)),
      );

      frame = window.requestAnimationFrame(render);
    };

    const onVisibility = () => {
      documentVisible = !document.hidden;
      if (!documentVisible && frame) {
        window.cancelAnimationFrame(frame);
        frame = 0;
      } else if (documentVisible && !frame) {
        previousTime = performance.now();
        frame = window.requestAnimationFrame(render);
      }
    };

    resize();
    window.addEventListener("resize", resize, { passive: true });
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    window.addEventListener("blur", onPointerLeave);
    document.documentElement.addEventListener("pointerleave", onPointerLeave, {
      passive: true,
    });
    window.addEventListener("nuc-guide-origin", receiveNucleusOrigin);
    document.addEventListener("visibilitychange", onVisibility);
    frame = window.requestAnimationFrame(render);

    return () => {
      window.cancelAnimationFrame(frame);
      window.clearTimeout(impactTimer);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("blur", onPointerLeave);
      document.documentElement.removeEventListener(
        "pointerleave",
        onPointerLeave,
      );
      window.removeEventListener("nuc-guide-origin", receiveNucleusOrigin);
      document.removeEventListener("visibilitychange", onVisibility);
      contact.classList.remove("is-orb-impact");
      window.dispatchEvent(
        new CustomEvent("nuc-guide-progress", {
          detail: { departure: 0, merge: 0 },
        }),
      );
    };
  }, [motionMode]);

  return (
    <canvas
      ref={canvasRef}
      className="energy-guide"
      aria-hidden="true"
    />
  );
}
