import InteractiveSite from "./components/InteractiveSite";
import { seoClusters } from "./data/seo";

const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL ||
  "https://nuc-vision.nucvisionassessoria.chatgpt.site";

const structuredData = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": `${siteUrl}/#organization`,
      name: "NUC Vision",
      url: siteUrl,
      logo: `${siteUrl}/nuc-mark.png`,
      description:
        "Consultoria e assessoria empresarial que conecta gestão, processos, estrutura comercial, marketing, automações, playbooks e acompanhamento da implementação.",
      email: "nucvisionassessoria@gmail.com",
      sameAs: [
        "https://www.instagram.com/nucvision",
        "https://www.facebook.com/profile.php?id=61575350444868",
      ],
      contactPoint: {
        "@type": "ContactPoint",
        contactType: "comercial",
        email: "nucvisionassessoria@gmail.com",
        availableLanguage: "Portuguese",
      },
      areaServed: {
        "@type": "Country",
        name: "Brasil",
      },
      knowsAbout: seoClusters.map((cluster) => cluster.title),
    },
    {
      "@type": "WebSite",
      "@id": `${siteUrl}/#website`,
      url: siteUrl,
      name: "NUC Vision",
      inLanguage: "pt-BR",
      publisher: {
        "@id": `${siteUrl}/#organization`,
      },
    },
    {
      "@type": "Service",
      "@id": `${siteUrl}/#service`,
      name: "Estruturação empresarial com implementação",
      serviceType:
        "Consultoria empresarial, processos, estrutura comercial, marketing e automação",
      provider: {
        "@id": `${siteUrl}/#organization`,
      },
      areaServed: {
        "@type": "Country",
        name: "Brasil",
      },
      hasOfferCatalog: {
        "@type": "OfferCatalog",
        name: "Soluções NUC Vision",
        itemListElement: [
          "Diagnóstico Estrutural",
          "Planejamento Completo",
          "Gestão de Jornada",
          "Mapeamento e padronização de processos",
          "Estruturação comercial e CRM",
          "Marketing e canais de aquisição",
          "Playbooks, treinamento e automações",
        ].map((name) => ({
          "@type": "Offer",
          itemOffered: {
            "@type": "Service",
            name,
          },
        })),
      },
    },
  ],
};

export default function Home() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(structuredData).replace(/</g, "\\u003c"),
        }}
      />
      <InteractiveSite />
    </>
  );
}
