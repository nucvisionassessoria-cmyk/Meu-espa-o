import { NextResponse } from "next/server";

type LeadPayload = {
  name?: unknown;
  whatsapp?: unknown;
  email?: unknown;
  socialProfile?: unknown;
  role?: unknown;
  teamSize?: unknown;
  monthlyRevenue?: unknown;
  website?: unknown;
  startedAt?: unknown;
};

type RateBucket = {
  count: number;
  resetAt: number;
};

const MAX_BODY_BYTES = 12_000;
const RATE_WINDOW_MS = 10 * 60 * 1_000;
const RATE_LIMIT = 6;
const MAX_RATE_BUCKETS = 500;
const CONTROL_CHARACTERS = /[\u0000-\u001f\u007f]/;

const allowedRoles = new Set([
  "Proprietário(a) / Sócio(a)",
  "Diretor(a)",
  "Gerente",
  "Coordenador(a) / Líder",
  "Analista / Especialista",
  "Outro cargo",
]);

const allowedTeamSizes = new Set([
  "1 a 5 colaboradores",
  "6 a 10 colaboradores",
  "11 a 30 colaboradores",
  "31 a 50 colaboradores",
  "51 a 100 colaboradores",
  "Mais de 100 colaboradores",
]);

const allowedRevenueRanges = new Set([
  "Até R$ 50 mil",
  "De R$ 50 mil a R$ 100 mil",
  "De R$ 100 mil a R$ 300 mil",
  "De R$ 300 mil a R$ 500 mil",
  "De R$ 500 mil a R$ 1 milhão",
  "Acima de R$ 1 milhão",
  "Prefiro conversar sobre isso",
]);

const globalRateState = globalThis as typeof globalThis & {
  __nucLeadRateBuckets?: Map<string, RateBucket>;
};

const rateBuckets =
  globalRateState.__nucLeadRateBuckets ?? new Map<string, RateBucket>();
globalRateState.__nucLeadRateBuckets = rateBuckets;

function json(
  body: { ok: boolean; message?: string },
  status = 200,
  headers?: HeadersInit,
) {
  return NextResponse.json(body, {
    status,
    headers: {
      "Cache-Control": "no-store, max-age=0",
      ...headers,
    },
  });
}

function normalize(value: unknown, maxLength: number) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, maxLength);
}

function containsControlCharacters(...values: string[]) {
  return values.some((value) => CONTROL_CHARACTERS.test(value));
}

function requestIsSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) return false;

  const fetchSite = request.headers.get("sec-fetch-site");
  return !fetchSite || fetchSite === "same-origin" || fetchSite === "none";
}

function consumeRateLimit(request: Request) {
  const ip =
    request.headers.get("x-vercel-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("cf-connecting-ip");
  if (!ip) return { allowed: true, retryAfter: 0 };

  const now = Date.now();
  if (rateBuckets.size >= MAX_RATE_BUCKETS) {
    for (const [key, bucket] of rateBuckets) {
      if (bucket.resetAt <= now) rateBuckets.delete(key);
    }
    if (rateBuckets.size >= MAX_RATE_BUCKETS) {
      rateBuckets.delete(rateBuckets.keys().next().value as string);
    }
  }

  const current = rateBuckets.get(ip);
  if (!current || current.resetAt <= now) {
    rateBuckets.set(ip, { count: 1, resetAt: now + RATE_WINDOW_MS });
    return { allowed: true, retryAfter: 0 };
  }

  if (current.count >= RATE_LIMIT) {
    return {
      allowed: false,
      retryAfter: Math.max(1, Math.ceil((current.resetAt - now) / 1_000)),
    };
  }

  current.count += 1;
  return { allowed: true, retryAfter: 0 };
}

function getSafeWebhook() {
  const rawWebhook = process.env.LEADS_WEBHOOK_URL;
  if (!rawWebhook) return null;

  try {
    const webhook = new URL(rawWebhook);
    const blockedHost =
      webhook.hostname === "localhost" ||
      webhook.hostname === "127.0.0.1" ||
      webhook.hostname === "0.0.0.0" ||
      webhook.hostname === "::1" ||
      webhook.hostname.endsWith(".local");

    if (
      webhook.protocol !== "https:" ||
      webhook.username ||
      webhook.password ||
      blockedHost
    ) {
      return null;
    }

    return webhook.toString();
  } catch {
    return null;
  }
}

export async function POST(request: Request) {
  if (!requestIsSameOrigin(request)) {
    return json(
      { ok: false, message: "Origem da solicitação não autorizada." },
      403,
    );
  }

  const contentType = request.headers.get("content-type")?.split(";", 1)[0];
  if (contentType !== "application/json") {
    return json(
      { ok: false, message: "Formato de solicitação não suportado." },
      415,
    );
  }

  const contentLength = Number(request.headers.get("content-length") || 0);
  if (contentLength > MAX_BODY_BYTES) {
    return json({ ok: false, message: "Solicitação muito grande." }, 413);
  }

  const rateLimit = consumeRateLimit(request);
  if (!rateLimit.allowed) {
    return json(
      {
        ok: false,
        message: "Muitas tentativas. Aguarde alguns minutos e tente novamente.",
      },
      429,
      { "Retry-After": String(rateLimit.retryAfter) },
    );
  }

  let payload: LeadPayload;
  try {
    const rawBody = await request.text();
    if (new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) {
      return json({ ok: false, message: "Solicitação muito grande." }, 413);
    }
    const parsed = JSON.parse(rawBody) as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Invalid payload");
    }
    payload = parsed as LeadPayload;
  } catch {
    return json(
      { ok: false, message: "Preencha os campos e tente novamente." },
      400,
    );
  }

  if (normalize(payload.website, 240)) {
    return json({ ok: true });
  }

  const elapsed =
    typeof payload.startedAt === "number"
      ? Date.now() - payload.startedAt
      : Number.NaN;
  if (!Number.isFinite(elapsed) || elapsed < 1_200) {
    return json(
      { ok: false, message: "Revise os dados e envie novamente." },
      400,
    );
  }

  const name = normalize(payload.name, 100);
  const whatsapp = normalize(payload.whatsapp, 20);
  const email = normalize(payload.email, 160).toLowerCase();
  const socialProfile = normalize(payload.socialProfile, 240);
  const role = normalize(payload.role, 80);
  const teamSize = normalize(payload.teamSize, 60);
  const monthlyRevenue = normalize(payload.monthlyRevenue, 80);

  if (!name || !whatsapp || !email || !role || !teamSize || !monthlyRevenue) {
    return json(
      { ok: false, message: "Preencha todos os campos obrigatórios." },
      400,
    );
  }

  if (
    containsControlCharacters(
      name,
      whatsapp,
      email,
      socialProfile,
      role,
      teamSize,
      monthlyRevenue,
    )
  ) {
    return json(
      { ok: false, message: "Revise os dados e envie novamente." },
      400,
    );
  }

  if (
    !allowedRoles.has(role) ||
    !allowedTeamSizes.has(teamSize) ||
    !allowedRevenueRanges.has(monthlyRevenue)
  ) {
    return json(
      { ok: false, message: "Selecione opções válidas no formulário." },
      400,
    );
  }

  const whatsappDigits = whatsapp.replace(/\D/g, "");
  if (whatsappDigits.length < 10 || whatsappDigits.length > 13) {
    return json(
      {
        ok: false,
        message: "Informe um WhatsApp válido, incluindo o DDD.",
      },
      400,
    );
  }

  const emailIsValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  if (!emailIsValid) {
    return json(
      { ok: false, message: "Informe um e-mail válido." },
      400,
    );
  }

  const webhook = getSafeWebhook();
  if (!webhook) {
    return json(
      {
        ok: false,
        message:
          "O canal de envio está em configuração. Entre em contato diretamente com a NUC por enquanto.",
      },
      503,
    );
  }

  try {
    const response = await fetch(webhook, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        nome: name,
        "telefone com ddd": whatsapp,
        email,
        "site ou instagram da empresa": socialProfile,
        cargo: role,
        "número total de colaboradores": teamSize,
        "faturamento médio mensal": monthlyRevenue,
      }),
      signal: AbortSignal.timeout(8_000),
    });
    if (!response.ok) throw new Error("Webhook rejected request");
  } catch {
    return json(
      {
        ok: false,
        message:
          "Não foi possível enviar agora. Aguarde um instante e tente novamente.",
      },
      502,
    );
  }

  return json({ ok: true });
}
