# NUC Vision — publicação na Vercel

Este pacote já está adaptado para a Vercel.

## Como publicar

1. Descompacte o ZIP.
2. Envie a pasta para um repositório no GitHub ou use a Vercel CLI.
3. Na Vercel, importe o projeto. O framework será reconhecido como Next.js.
4. Em **Settings > Environment Variables**, adicione:
   - `LEADS_WEBHOOK_URL`: o webhook do Make usado pelo formulário.
   - `NEXT_PUBLIC_SITE_URL`: o endereço final do site, por exemplo `https://www.nucvision.com.br`.
5. Faça o deploy.

Não coloque o webhook diretamente em arquivos públicos nem envie um arquivo `.env.local` ao GitHub.

## Configuração esperada

- Build Command: `npm run build`
- Install Command: `npm ci`
- Output Directory: deixe em branco (padrão do Next.js)
- Node.js: 22.x

Após conectar o domínio definitivo, confira `robots.txt`, `sitemap.xml` e faça um envio real pelo formulário.
